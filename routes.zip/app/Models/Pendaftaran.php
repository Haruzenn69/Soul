<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Pendaftaran extends Model
{
    public const STATUS_PENDING = 'pending';

    public const STATUS_DITERIMA = 'diterima';

    public const STATUS_DITOLAK = 'ditolak';

    public const STATUS_NONAKTIF = 'nonaktif';

    public const STATUS_KELUAR = 'keluar';

    public const STATUS_PERINGATAN = 'peringatan';

    public const STATUS_LULUS = 'lulus';

    protected $fillable = [
        'siswa_id',
        'ekskul_id',
        'tanggal_daftar',
        'status',
        'alasan',
    ];

    protected $casts = [
        'tanggal_daftar' => 'date',
    ];

    public function siswa(): BelongsTo
    {
        return $this->belongsTo(Siswa::class);
    }

    public function ekskul(): BelongsTo
    {
        return $this->belongsTo(Ekskul::class);
    }

    public function presensis(): HasMany
    {
        return $this->hasMany(Presensi::class);
    }

    public function penilaians(): HasMany
    {
        return $this->hasMany(Penilaian::class);
    }

    public function isActive(): bool
    {
        return in_array($this->status, [self::STATUS_DITERIMA, self::STATUS_PERINGATAN], true);
    }
}
