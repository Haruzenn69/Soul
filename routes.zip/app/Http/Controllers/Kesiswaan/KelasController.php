<?php

namespace App\Http\Controllers\Kesiswaan;

use App\Http\Controllers\Controller;
use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\TahunAjaran;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class KelasController extends Controller
{
    public function index(Request $request): View
    {
        $currentTingkat = $request->input('tingkat');
        $q = $request->input('q');

        // Mengikuti tahun ajaran aktif secara default jika tidak dipilih secara eksplisit
        $activeYear = TahunAjaran::where('status', 'aktif')->first();
        if ($request->has('tahun_ajaran_id')) {
            $currentTahunAjaranId = $request->input('tahun_ajaran_id') === 'semua' ? null : (int) $request->input('tahun_ajaran_id');
        } else {
            $currentTahunAjaranId = $activeYear?->id;
        }

        $sort = in_array($request->input('sort'), ['nama', 'tingkat', 'siswas_count', 'created_at'], true) ? $request->input('sort') : 'nama';
        $direction = $request->input('direction') === 'desc' ? 'desc' : 'asc';

        $kelas = Kelas::with(['tahunAjaran', 'siswas'])
            ->withCount('siswas')
            ->when($q, function ($query) use ($q) {
                $query->where('nama', 'like', '%'.$q.'%');
            })
            ->when($currentTingkat, fn ($query) => $query->where('tingkat', $currentTingkat))
            ->when($currentTahunAjaranId, fn ($query) => $query->where('tahun_ajaran_id', $currentTahunAjaranId))
            ->orderBy($sort, $direction)
            ->paginate(12)
            ->withQueryString();

        foreach ($kelas as $class) {
            if ($class->tahunAjaran?->status !== 'aktif' && $class->tahunAjaran) {
                $class->siswas_count = Siswa::query()->where(function ($query) use ($class) {
                    $query->whereHas('classHistories', fn ($history) => $history
                            ->where('tahun_ajaran', $class->tahunAjaran->nama)
                            ->where('kelas_asal', $class->nama))
                        ->orWhere(function ($sub) use ($class) {
                            $sub->where('kelas_id', $class->id)
                                ->whereDoesntHave('classHistories', fn ($h) => $h->where('tahun_ajaran', $class->tahunAjaran->nama));
                        });
                })->distinct()->count('siswas.id');
            } else {
                $class->siswas_count = Siswa::query()->where('kelas_id', $class->id)->count();
            }
        }

        $classFilter = Kelas::query()->when($currentTahunAjaranId, fn ($query) => $query->where('tahun_ajaran_id', $currentTahunAjaranId));
        $counts = [
            'all' => (clone $classFilter)->count(),
            'x' => (clone $classFilter)->where('tingkat', 'x')->count(),
            'xi' => (clone $classFilter)->where('tingkat', 'xi')->count(),
            'xii' => (clone $classFilter)->where('tingkat', 'xii')->count(),
            'total_siswa' => Siswa::whereHas('kelas', fn ($query) => $query->when($currentTahunAjaranId, fn ($q) => $q->where('tahun_ajaran_id', $currentTahunAjaranId)))
                ->whereIn('status', ['aktif', 'menunggu_penempatan'])
                ->count(),
        ];

        return view('kesiswaan.kelas.index', [
            'kelas' => $kelas,
            'counts' => $counts,
            'tahunAjarans' => TahunAjaran::orderBy('nama', 'desc')->get(),
            'activeTingkat' => $currentTingkat,
            'currentTahunAjaranId' => $currentTahunAjaranId,
            'activeYear' => $activeYear,
            'sort' => $sort,
            'direction' => $direction,
        ]);
    }

    public function show(Request $request, Kelas $kela): View
    {
        $kela->load(['tahunAjaran']);

        $sort = in_array($request->input('sort'), ['nama', 'nis', 'created_at'], true) ? $request->input('sort') : 'nama';
        $direction = $request->input('direction') === 'desc' ? 'desc' : 'asc';

        $historicalYear = $kela->tahunAjaran?->status !== 'aktif' && $kela->tahunAjaran;
        $siswaQuery = Siswa::query()->where(function ($query) use ($kela, $historicalYear) {
            if ($historicalYear) {
                $query->whereHas('classHistories', fn ($history) => $history
                    ->where('tahun_ajaran', $kela->tahunAjaran->nama)
                    ->where('kelas_asal', $kela->nama))
                ->orWhere(function ($sub) use ($kela) {
                    $sub->where('kelas_id', $kela->id)
                        ->whereDoesntHave('classHistories', fn ($h) => $h->where('tahun_ajaran', $kela->tahunAjaran->nama));
                });
            } else {
                $query->where('kelas_id', $kela->id);
            }
        });

        $siswas = (clone $siswaQuery)
            ->when($request->filled('q'), function ($query) use ($request) {
                $q = '%'.$request->input('q').'%';
                $query->where(function ($sub) use ($q) {
                    $sub->where('nama', 'like', $q)
                        ->orWhere('nis', 'like', $q)
                        ->orWhere('email', 'like', $q);
                });
            })
            ->when($request->filled('jenis_kelamin'), fn ($query) => $query->where('jenis_kelamin', $request->input('jenis_kelamin')))
            ->when($request->filled('jabatan'), fn ($query) => $query->where('jabatan', $request->input('jabatan')))
            ->orderBy($sort, $direction)
            ->paginate(15)
            ->withQueryString();

        $stats = [
            'total' => (clone $siswaQuery)->count(),
            'laki' => (clone $siswaQuery)->where('jenis_kelamin', 'laki-laki')->count(),
            'perempuan' => (clone $siswaQuery)->where('jenis_kelamin', 'perempuan')->count(),
            'ketua' => (clone $siswaQuery)->where('jabatan', 'ketua')->count(),
        ];

        return view('kesiswaan.kelas.show', [
            'kelas' => $kela,
            'siswas' => $siswas,
            'stats' => $stats,
            'sort' => $sort,
            'direction' => $direction,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validatedData($request);

        $nama = $this->buildNama($data['tingkat'], $data['jurusan'], $data['rombel']);

        if ($this->kelasExists($nama, $data['tahun_ajaran_id'])) {
            return back()->with('error', "Kelas {$nama} sudah ada pada tahun ajaran ini.");
        }

        Kelas::create([
            'nama' => $nama,
            'tingkat' => $data['tingkat'],
            'jurusan' => $data['jurusan'],
            'rombel' => $data['rombel'],
            'tahun_ajaran_id' => $data['tahun_ajaran_id'],
        ]);

        return back()->with('success', "Kelas {$nama} berhasil ditambahkan.");
    }

    public function update(Request $request, Kelas $kela): RedirectResponse
    {
        $data = $this->validatedData($request);

        $nama = $this->buildNama($data['tingkat'], $data['jurusan'], $data['rombel']);

        if ($this->kelasExists($nama, $data['tahun_ajaran_id'], $kela->id)) {
            return back()->with('error', "Kelas {$nama} sudah ada pada tahun ajaran ini.");
        }

        $kela->update([
            'nama' => $nama,
            'tingkat' => $data['tingkat'],
            'jurusan' => $data['jurusan'],
            'rombel' => $data['rombel'],
            'tahun_ajaran_id' => $data['tahun_ajaran_id'],
        ]);

        return back()->with('success', "Kelas {$nama} berhasil diperbarui.");
    }

    public function destroy(Kelas $kela): RedirectResponse
    {
        if ($kela->siswas()->exists()) {
            return back()->with('error', "Kelas {$kela->nama} masih memiliki siswa dan tidak bisa dihapus.");
        }

        $nama = $kela->nama;
        $kela->delete();

        return back()->with('success', "Kelas {$nama} berhasil dihapus.");
    }

    private function validatedData(Request $request): array
    {
        return Validator::make($request->all(), [
            'tingkat' => ['required', 'in:'.implode(',', array_keys(config('kelas.tingkat')))],
            'jurusan' => ['required', Rule::in(array_keys(config('kelas.jurusan')))],
            // Rombel bersifat opsional - boleh dikosongkan.
            'rombel' => ['nullable', 'integer', 'min:1'],
            'tahun_ajaran_id' => ['required', 'exists:tahun_ajarans,id'],
        ])->validate();
    }

    private function buildNama(string $tingkat, string $jurusan, ?string $rombel = null): string
    {
        $labelTingkat = config("kelas.tingkat.{$tingkat}", $tingkat);
        $labelJurusan = config("kelas.jurusan.{$jurusan}.{$tingkat}", $jurusan);

        return trim(implode(' ', array_filter([$labelTingkat, $labelJurusan, $rombel])));
    }

    private function kelasExists(string $nama, int $tahunAjaranId, ?int $ignoreId = null): bool
    {
        return Kelas::query()
            ->where('nama', $nama)
            ->where('tahun_ajaran_id', $tahunAjaranId)
            ->when($ignoreId, fn ($query) => $query->where('id', '!=', $ignoreId))
            ->exists();
    }
}
