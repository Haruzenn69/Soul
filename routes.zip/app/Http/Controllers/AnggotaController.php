<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\KetuaEkskul;
use App\Models\Pendaftaran;
use App\Models\Siswa;
use App\Services\ArsipEkskulService;
use App\Services\NotifikasiService;
use App\Support\TableKit;
use Illuminate\Http\Request;

class AnggotaController extends Controller
{
    use KetuaEkskul;

    public function index(Request $request)
    {
        $ekskul = $this->ekskul();
        $base = Pendaftaran::where('ekskul_id', $ekskul->id)
            ->whereIn('status', [Pendaftaran::STATUS_DITERIMA, Pendaftaran::STATUS_NONAKTIF, Pendaftaran::STATUS_PERINGATAN, Pendaftaran::STATUS_KELUAR]);

        $totalAnggotas = (clone $base)->count();

        // Tanpa filter status, hanya anggota aktif yang ditampilkan.
        $statusDipilih = $request->input('status');
        $scopeAktif = ! $request->filled('status') || $statusDipilih === 'semua';

        // Angka legenda dihitung dari seluruh anggota agar tidak ikut terfilter.
        $peringatanCount = (clone $base)->where('status', Pendaftaran::STATUS_PERINGATAN)->count();
        $nonaktifCount = (clone $base)->where('status', Pendaftaran::STATUS_NONAKTIF)->count();
        $keluarCount = (clone $base)->where('status', Pendaftaran::STATUS_KELUAR)->count();

        $query = (clone $base)
            ->when($scopeAktif, fn ($query) => $query->whereIn('status', [Pendaftaran::STATUS_DITERIMA, Pendaftaran::STATUS_PERINGATAN]))
            ->when($request->filled('cari'), function ($query) use ($request) {
                $cari = $request->input('cari');
                $query->whereHas('siswa', fn ($s) => $s->where('nama', 'like', "%{$cari}%")->orWhere('nis', 'like', "%{$cari}%"));
            })
            ->when($request->filled('status') && $statusDipilih !== 'semua', fn ($query) => $query->where('status', $statusDipilih));

        [$sort, $direction] = TableKit::sort(['nama', 'nis', 'status', 'tanggal_daftar'], 'tanggal_daftar', 'desc');

        $anggotas = (clone $query)
            ->with('siswa.kelas')
            ->orderBy($sort === 'nama' || $sort === 'nis' ? Siswa::select($sort)->whereColumn('siswas.id', 'pendaftarans.siswa_id') : $sort, $direction)
            ->paginate(10)
            ->withQueryString();

        // Arsip hanya dirakit ketika filter diaktifkan; label filter memakai
        // hitungan ringan yang tidak memuat detail.
        $tampilArsip = $request->boolean('arsip');
        $arsipService = app(ArsipEkskulService::class);
        $arsipTotal = $arsipService->hitungTotal($ekskul);

        $arsip = $tampilArsip
            ? $arsipService->arsip($ekskul)
            : ['ketuaSelesai' => collect(), 'anggotaLulus' => collect(), 'total' => $arsipTotal];

        return view('ketua.anggota.index', compact('anggotas', 'peringatanCount', 'nonaktifCount', 'keluarCount', 'totalAnggotas', 'sort', 'direction', 'tampilArsip', 'arsip', 'arsipTotal'));
    }

    public function updateStatus(Request $request, Pendaftaran $pendaftaran)
    {
        $this->ensureEkskul($pendaftaran);

        $validated = $request->validate([
            'status' => ['required', 'in:diterima,peringatan,nonaktif'],
        ], [
            'status.required' => 'Status anggota wajib dipilih.',
            'status.in' => 'Status anggota tidak valid.',
        ]);

        $targetStatus = $validated['status'];

        $protected = $pendaftaran->siswa_id === auth()->user()->siswa?->id
            || $pendaftaran->siswa?->jabatan === 'ketua';

        if ($protected && in_array($targetStatus, [Pendaftaran::STATUS_PERINGATAN, Pendaftaran::STATUS_NONAKTIF])) {
            return back()->with('error', 'Kamu (ketua) tidak bisa memberi peringatan atau menonaktifkan dirimu sendiri.');
        }

        if ($pendaftaran->status === $targetStatus) {
            return back()->with('error', 'Status anggota sudah '.$this->labelStatus($targetStatus).'.');
        }

        $pendaftaran->update(['status' => $targetStatus]);

        $namaSiswa = $pendaftaran->siswa?->nama ?? 'Siswa';

        [$judul, $pesan, $tipe] = match ($targetStatus) {
            Pendaftaran::STATUS_PERINGATAN => [
                'Peringatan dari Ketua Ekskul',
                $namaSiswa.', kamu mendapatkan peringatan dari ketua '.$pendaftaran->ekskul->nama_ekskul.'. Tingkatkan keaktifan dan kehadiranmu, ya!',
                'ditolak',
            ],
            Pendaftaran::STATUS_NONAKTIF => [
                'Dinonaktifkan dari Ekskul',
                $namaSiswa.', kamu telah dinonaktifkan dari ekskul '.$pendaftaran->ekskul->nama_ekskul.' oleh ketua ekskul. Hubungi ketua jika ini kurang tepat.',
                'ditolak',
            ],
            default => [
                'Status Anggota Diaktifkan Kembali',
                $namaSiswa.', status anggota kamu di ekskul '.$pendaftaran->ekskul->nama_ekskul.' telah diaktifkan kembali. Selamat beraktivitas!',
                'diterima',
            ],
        };

        NotifikasiService::statusAnggotaDiubah($pendaftaran, $targetStatus, $judul, $pesan, $tipe);

        return back()->with('success', 'Status '.$namaSiswa.' berhasil diubah menjadi '.$this->labelStatus($targetStatus).'.');
    }

    private function labelStatus(string $status): string
    {
        return match ($status) {
            Pendaftaran::STATUS_DITERIMA => 'Aktif',
            Pendaftaran::STATUS_PERINGATAN => 'Peringatan',
            Pendaftaran::STATUS_NONAKTIF => 'Nonaktif',
            Pendaftaran::STATUS_KELUAR => 'Keluar',
            Pendaftaran::STATUS_LULUS => 'Lulus',
            default => $status,
        };
    }
}
