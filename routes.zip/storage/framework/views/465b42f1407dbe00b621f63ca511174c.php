<?php $__env->startSection('title', 'Dashboard Pembina'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sky-400 via-blue-400 to-blue-600 p-6 md:p-8 lg:pb-14 text-white shadow-xl shadow-sky-200 animate-fade-up">
        <div class="absolute inset-0 pointer-events-none">
            <div class="absolute -top-20 -right-10 w-72 h-72 rounded-full bg-amber-200/40 blur-3xl"></div>
            <div class="absolute -bottom-24 -left-10 w-72 h-72 rounded-full bg-white/10 blur-3xl"></div>
            <div class="absolute top-10 right-1/4 w-16 h-16 rounded-full bg-amber-300/50 blur-2xl"></div>
        </div>

        <div class="relative grid lg:grid-cols-5 gap-8 items-center">
            <!-- TEXT + CTA -->
            <div class="lg:col-span-3">
                <div class="flex items-center gap-2 mb-3 flex-wrap">
                    <span class="px-3 py-1 rounded-full bg-white/15 backdrop-blur border border-white/20 text-[10px] font-bold tracking-wide uppercase">Dashboard Pembina</span>
                    <?php $__currentLoopData = $ekskulsByBidang ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidang => $ekskulBidangList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="px-3 py-1 rounded-full bg-amber-300/30 backdrop-blur border border-amber-200/40 text-[10px] font-bold tracking-wide uppercase flex items-center gap-1.5">
                            <span class="w-1.5 h-1.5 rounded-full bg-amber-300 animate-pulse"></span>
                            Membina <?php echo e($bidang); ?>

                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <h1 class="text-2xl md:text-3xl font-extrabold tracking-tight leading-tight">
                    Halo, <?php echo e($pembina->nama ?? 'Pembina'); ?>!
                </h1>
                <p class="text-sm text-white/85 mt-1.5 font-medium">
                    <?php echo e(\Carbon\Carbon::now()->isoFormat('dddd, D MMMM Y')); ?> · Semester Ganjil 2026/2027
                </p>
                <p class="text-xs text-white/70 mt-3 max-w-lg leading-relaxed">
                    Pantau keanggotaan, presensi, dan laporan ekskul binaanmu dengan mudah di page ini.
                </p>

                <div class="flex gap-3 flex-wrap mt-6">
                    <a href="<?php echo e(route('pembina.anggota')); ?>" class="inline-flex items-center justify-center gap-2 px-5 py-3 bg-white text-sky-700 font-bold text-xs rounded-2xl shadow-lg shadow-sky-900/10 hover:bg-sky-50 hover:-translate-y-0.5 transition-all">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        Kelola Anggota
                    </a>
                    <a href="<?php echo e(route('pembina.presensi')); ?>" class="inline-flex items-center justify-center gap-2 px-5 py-3 bg-white/10 backdrop-blur border border-white/20 text-white font-bold text-xs rounded-2xl hover:bg-white/20 transition-all">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                        Lihat Presensi
                    </a>
                </div>
            </div>

            <!-- ILLUSTRATIVE PANEL + FLOATING STATS (desktop only) -->
            <div class="lg:col-span-2 relative hidden lg:block">
                <div class="relative h-52 rounded-3xl bg-white/10 backdrop-blur border border-white/20 overflow-hidden flex items-center justify-center">
                    <div class="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-amber-300/30 blur-2xl"></div>
                    <div class="absolute -bottom-10 -left-6 w-32 h-32 rounded-full bg-white/20 blur-2xl"></div>
                    <div class="relative w-24 h-24 rounded-3xl bg-white/20 backdrop-blur border border-white/30 flex items-center justify-center text-white shadow-inner animate-floaty">
                        <svg class="w-11 h-11" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                    </div>
                </div>

                <!-- floating stat card overlapping bottom edge -->
                <div class="absolute -bottom-10 left-3 right-3 z-10 grid grid-cols-3 gap-2 bg-white rounded-2xl shadow-xl shadow-sky-900/10 p-3">
                    <div class="text-center border-r border-slate-100 pr-1">
                        <p class="text-base font-extrabold text-sky-700 leading-none"><?php echo e($ekskuls->count()); ?></p>
                        <p class="text-[9px] text-slate-400 font-semibold mt-1">Ekskul</p>
                    </div>
                    <div class="text-center border-r border-slate-100 px-1">
                        <p class="text-base font-extrabold text-amber-600 leading-none"><?php echo e($anggotaAktifCount ?? 0); ?></p>
                        <p class="text-[9px] text-slate-400 font-semibold mt-1">Anggota</p>
                    </div>
                    <div class="text-center pl-1">
                        <p class="text-base font-extrabold text-sky-700 leading-none"><?php echo e(count($pendaftaranPending ?? [])); ?></p>
                        <p class="text-[9px] text-slate-400 font-semibold mt-1">Pendaftaran</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="relative mt-6 pt-5 border-t border-white/15 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <a href="<?php echo e(route('pembina.anggota')); ?>" class="group flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-white/10 backdrop-blur border border-white/10 hover:bg-white/20 transition-all">
                <div class="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                </div>
                <div class="text-left">
                    <p class="text-xs font-bold leading-none">Anggota</p>
                    <p class="text-[10px] text-white/70 mt-1 leading-none">Data Keanggotaan</p>
                </div>
            </a>
            <a href="<?php echo e(route('pembina.presensi')); ?>" class="group flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-white/10 backdrop-blur border border-white/10 hover:bg-white/20 transition-all">
                <div class="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                </div>
                <div class="text-left">
                    <p class="text-xs font-bold leading-none">Presensi</p>
                    <p class="text-[10px] text-white/70 mt-1 leading-none">Rekap Kehadiran</p>
                </div>
            </a>
            <a href="<?php echo e(route('pembina.laporan.index')); ?>" class="group flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-white/10 backdrop-blur border border-white/10 hover:bg-white/20 transition-all">
                <div class="w-8 h-8 rounded-lg bg-amber-300/40 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
                </div>
                <div class="text-left">
                    <p class="text-xs font-bold leading-none">Laporan</p>
                    <p class="text-[10px] text-white/70 mt-1 leading-none">Cetak & Approve</p>
                </div>
            </a>
        </div>
    </div>

    
    <div class="grid grid-cols-3 gap-3 lg:hidden">
        <div class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-sky-100 to-white dark:from-sky-950/30 dark:to-neutral-800 border border-sky-200 dark:border-neutral-700 p-3 md:p-5 shadow-md shadow-sky-100 dark:shadow-sky-900/30 animate-fade-up" style="animation-delay: .1s">
            <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 tracking-wider uppercase">Ekskul Dibina</p>
            <h3 class="text-xl md:text-3xl font-extrabold mt-0.5 md:mt-1.5 text-sky-700 dark:text-sky-300"><?php echo e($ekskuls->count()); ?></h3>
            <p class="text-[11px] font-semibold <?php echo e($ekskuls->count() > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'); ?> mt-0.5 md:mt-1"><?php echo e($ekskuls->count() > 0 ? 'Aktif' : 'Belum'); ?></p>
        </div>
        <div class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-100 to-yellow-50 dark:from-amber-950/30 dark:to-amber-900/30 border border-amber-200 dark:border-amber-800 p-3 md:p-5 shadow-md shadow-amber-100 dark:shadow-amber-900/30 animate-fade-up" style="animation-delay: .2s">
            <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 tracking-wider uppercase">Anggota Aktif</p>
            <h3 class="text-xl md:text-3xl font-extrabold mt-0.5 md:mt-1.5 text-amber-600 dark:text-amber-400"><?php echo e($anggotaAktifCount ?? 0); ?></h3>
            <p class="text-[11px] font-semibold text-amber-700 dark:text-amber-300 mt-0.5 md:mt-1">Siswa</p>
        </div>
        <div class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-sky-100 to-white dark:from-sky-950/30 dark:to-neutral-800 border border-sky-200 dark:border-neutral-700 p-3 md:p-5 shadow-md shadow-sky-100 dark:shadow-sky-900/30 animate-fade-up" style="animation-delay: .3s">
            <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 tracking-wider uppercase">Pendaftaran</p>
            <h3 class="text-xl md:text-3xl font-extrabold mt-0.5 md:mt-1.5 text-sky-700 dark:text-sky-300"><?php echo e(count($pendaftaranPending ?? [])); ?></h3>
            <p class="text-[11px] font-semibold text-sky-600 dark:text-sky-400 mt-0.5 md:mt-1">Menunggu</p>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:pt-6">

        <!-- LEFT COLUMN -->
        <div class="lg:col-span-2 space-y-6">
            
            <?php if(($ekskulsByBidang ?? collect())->isNotEmpty()): ?>
                <?php $__currentLoopData = $ekskulsByBidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidangNama => $ekskulBidangList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $badgeClass = \App\Support\EkskulInfo::bidangBadgeClass($bidangNama);
                    $totalAktifBidang = 0;
                    foreach($ekskulBidangList as $eksB) {
                        $totalAktifBidang += \App\Models\Pendaftaran::where('ekskul_id', $eksB->id)->where('status', 'diterima')->count();
                    }
                ?>
                <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-sky-100 dark:border-neutral-800 shadow-lg shadow-sky-100/60 dark:shadow-sky-900/30 overflow-hidden animate-fade-up" style="animation-delay: .15s">
                    <div class="px-6 py-4 flex items-center justify-between border-b border-sky-50 dark:border-neutral-800">
                        <div class="flex items-center gap-3">
                            <span class="px-2.5 py-1 rounded-xl border text-[11px] font-bold <?php echo e($badgeClass); ?>"><?php echo e($bidangNama); ?></span>
                            <div>
                                <h2 class="text-sm font-extrabold text-slate-900">Bidang <?php echo e($bidangNama); ?></h2>
                                <p class="text-[11px] text-slate-400"><?php echo e($ekskulBidangList->count()); ?> ekskul · <?php echo e($totalAktifBidang); ?> anggota aktif</p>
                            </div>
                        </div>
                        <a href="<?php echo e(route('pembina.anggota')); ?>" class="text-[11px] font-bold text-amber-700 dark:text-amber-400 hover:text-amber-800 dark:hover:text-amber-300 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 px-3 py-1.5 rounded-full transition shrink-0">
                            Kelola Anggota →
                        </a>
                    </div>
                    <div class="divide-y divide-sky-50 dark:divide-neutral-800">
                        <?php $__currentLoopData = $ekskulBidangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eksB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $ketuaEksB = $eksB->ketua();
                            $anggotaCount = \App\Models\Pendaftaran::where('ekskul_id', $eksB->id)->where('status', 'diterima')->count();
                        ?>
                        <div class="px-6 py-4 flex items-center justify-between gap-4">
                            <div class="flex items-center gap-3 min-w-0">
                                <div class="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-100 to-blue-100 flex items-center justify-center text-sky-700 font-extrabold text-xs shrink-0 border border-sky-200">
                                    <?php echo e(strtoupper(substr($eksB->nama_ekskul, 0, 2))); ?>

                                </div>
                                <div class="min-w-0">
                                    <h4 class="text-xs font-extrabold text-slate-900 dark:text-white truncate"><?php echo e($eksB->nama_ekskul); ?></h4>
<p class="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                                        <?php echo e($anggotaCount); ?> Anggota Aktif
                                        <?php if($ketuaEksB): ?> · Ketua: <span class="font-semibold text-amber-700"><?php echo e($ketuaEksB->nama); ?></span><?php endif; ?>
                                    </p>
                                </div>
                            </div>
                            <div class="flex items-center gap-2 shrink-0">
                                <?php if($eksB->status): ?>
                                    <span class="px-2 py-1 rounded-lg text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/50">Aktif</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 rounded-lg text-[10px] font-bold bg-slate-50 dark:bg-neutral-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-neutral-700">Nonaktif</span>
                                <?php endif; ?>
                                <?php if($eksB->is_open_recruitment): ?>
                                    <span class="px-2 py-1 rounded-lg text-[10px] font-bold bg-sky-50 dark:bg-sky-950/30 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800/50">Buka Rekrutmen</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="bg-white rounded-3xl border border-sky-100 shadow-lg shadow-sky-100/60 p-10 text-center animate-fade-up">
                    <div class="mx-auto w-16 h-16 rounded-2xl bg-sky-50 flex items-center justify-center text-sky-300 border border-sky-100 mb-3">
                        <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5"/></svg>
                    </div>
                    <p class="text-xs font-semibold text-slate-500">Belum ada ekskul binaan</p>
                    <p class="text-[11px] text-slate-400 mt-1">Hubungi kesiswaan untuk mendapatkan binaan ekskul</p>
                </div>
            <?php endif; ?>

            <!-- AGENDA KEGIATAN MENDATANG -->
            <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-sky-100 dark:border-neutral-800 shadow-lg shadow-sky-100/60 dark:shadow-sky-900/30 overflow-hidden animate-fade-up" style="animation-delay: .2s">
                <div class="px-6 py-5 flex justify-between items-center border-b border-sky-50 dark:border-neutral-800">
                    <div>
                        <h2 class="text-sm font-extrabold text-slate-900 dark:text-white">Kegiatan Mendatang</h2>
                        <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">Semua agenda ekskul yang akan datang</p>
                    </div>
                    <span class="text-[11px] font-semibold text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-800/50 px-3 py-1.5 rounded-full"><?php echo e($kegiatanMendatang->count() ?? 0); ?> Agenda</span>
                </div>

                <?php if(($kegiatanMendatang ?? collect())->count() > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead>
                                <tr class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                    <th class="px-6 py-3">Kegiatan</th>
                                    <th class="px-6 py-3">Tanggal</th>
                                    <th class="px-6 py-3">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kegiatanMendatang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-t border-sky-50 dark:border-neutral-800 hover:bg-sky-50/50 dark:hover:bg-sky-950/30 transition-colors">
                                        <td class="px-6 py-3.5">
                                            <div class="flex items-center gap-3">
                                                <div class="w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br from-sky-400 to-blue-500 text-white flex flex-col items-center justify-center shadow-sm shadow-sky-200">
                                                    <span class="text-xs font-extrabold leading-none"><?php echo e(\Carbon\Carbon::parse($kegiatan->tanggal_kegiatan)->format('d')); ?></span>
                                                    <span class="text-[7px] font-bold uppercase leading-tight opacity-80"><?php echo e(\Carbon\Carbon::parse($kegiatan->tanggal_kegiatan)->format('M')); ?></span>
                                                </div>
                                                <div class="min-w-0">
                                                    <span class="text-xs font-bold text-slate-800 dark:text-white"><?php echo e($kegiatan->materi ?? 'Kegiatan'); ?></span>
                                                    <p class="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5"><?php echo e($kegiatan->ekskul->nama_ekskul ?? 'Ekskul'); ?></p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-3.5">
                                            <span class="text-[11px] text-slate-500 dark:text-slate-400"><?php echo e(\Carbon\Carbon::parse($kegiatan->tanggal_kegiatan)->isoFormat('dddd, DD MMM Y')); ?></span>
                                        </td>
                                        <td class="px-6 py-3.5">
                                            <?php if($index === 0): ?>
                                                <span class="inline-flex px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 text-amber-700 dark:text-amber-300 text-[10px] font-bold">Terdekat</span>
                                            <?php else: ?>
                                                <span class="inline-flex px-2.5 py-1 rounded-full bg-sky-50 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-800/50 text-sky-600 dark:text-sky-400 text-[10px] font-bold">Terjadwal</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-10">
                        <div class="mx-auto w-16 h-16 rounded-2xl bg-sky-50 dark:bg-sky-950/30 flex items-center justify-center text-sky-300 dark:text-sky-600 border border-sky-100 dark:border-sky-800/50">
                            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                            </svg>
                        </div>
                        <p class="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-3">Belum ada agenda mendatang</p>
                        <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-1">Agenda ekskul akan muncul di sini.</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

            <!-- PELATIH EKSRUL -->
            <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-sky-100 dark:border-neutral-800 shadow-lg shadow-sky-100/60 dark:shadow-sky-900/30 overflow-hidden animate-fade-up" style="animation-delay: .25s">
                <div class="px-6 py-5 flex justify-between items-center border-b border-sky-50 dark:border-neutral-800">
                    <div>
                        <h2 class="text-sm font-extrabold text-slate-900 dark:text-white">Pelatih Ekskul</h2>
                        <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">Tentukan pelatih terverifikasi untuk ekskul binaanmu</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <a href="<?php echo e(route('pembina.pelatih.index')); ?>"
                           class="text-[11px] font-bold text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300 bg-sky-50 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-800/50 px-3 py-1.5 rounded-full transition inline-flex items-center gap-1">
                            Kelola Pelatih
                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                        </a>
                    </div>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $ekskuls ?? collect(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekskulBinaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-5">
                        <form method="POST" action="<?php echo e(route('pembina.ekskul.pelatih', $ekskulBinaan)); ?>" class="p-3.5 bg-gradient-to-r from-sky-50 to-white dark:from-sky-950/30 dark:to-neutral-800/30 rounded-xl border border-sky-100 dark:border-neutral-700 hover:border-sky-200 dark:hover:border-neutral-600 transition">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <p class="text-xs font-bold text-slate-800 mb-1"><?php echo e($ekskulBinaan->nama_ekskul); ?></p>
                            <p class="text-[10px] text-slate-400 dark:text-slate-500 mb-3">Pelatih saat ini: <span class="font-bold text-slate-600 dark:text-slate-400"><?php echo e($ekskulBinaan->pelatih?->nama ?? '-'); ?></span></p>
                            <div class="flex gap-2">
                                <select name="pelatih_id"
                                    class="flex-1 min-w-0 px-3 py-2.5 bg-white dark:bg-neutral-800 border border-sky-100 dark:border-neutral-700 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-100 dark:focus:ring-sky-900/30 transition">
                                    <option value="" <?php echo e($ekskulBinaan->pelatih_id ? '' : 'selected'); ?>>Tanpa pelatih</option>
                                    <?php $__currentLoopData = $pelatihs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pl->id); ?>" <?php echo e($ekskulBinaan->pelatih_id == $pl->id ? 'selected' : ''); ?>><?php echo e($pl->nama); ?> (<?php echo e($pl->status); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="shrink-0 px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl transition">
                                    Simpan
                                </button>
                            </div>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-10">
                        <div class="mx-auto w-16 h-16 rounded-2xl bg-sky-50 flex items-center justify-center text-sky-300 border border-sky-100">
                            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18z"/>
                            </svg>
                        </div>
                        <p class="text-xs font-semibold text-slate-500 mt-3">Belum ada ekskul binaan</p>
                        <p class="text-[11px] text-slate-400 mt-1">Hubungi kesiswaan untuk mendapatkan binaan ekskul</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- LAPORAN BULANAN -->
            <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-sky-100 dark:border-neutral-800 shadow-lg shadow-sky-100/60 dark:shadow-sky-900/30 overflow-hidden animate-fade-up" style="animation-delay: .3s">
                <div class="px-6 py-5 flex justify-between items-center border-b border-sky-50 dark:border-neutral-800">
                    <div>
                        <h2 class="text-sm font-extrabold text-slate-900 dark:text-white">Laporan Bulanan</h2>
                        <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">Draft laporan ekskul</p>
                    </div>
                    <a href="<?php echo e(route('pembina.laporan.index')); ?>" class="text-xs font-bold text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1">
                        Cetak
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M9 5l7 7-7 7"/></svg>
                    </a>
                </div>

                <div class="p-5">
                    <?php $__empty_1 = true; $__currentLoopData = $laporanDraft ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-3.5 bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-950/30 dark:to-amber-900/30 rounded-xl border border-amber-100 dark:border-amber-800/50 flex items-center justify-between mb-3 gap-3 hover:border-amber-200 dark:hover:border-amber-800/50 transition">
                            <div class="flex items-center gap-3 min-w-0">
                                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-300 to-yellow-400 text-amber-900 flex items-center justify-center text-xs font-extrabold shadow-md shadow-amber-200 dark:shadow-amber-900/30 shrink-0">
                                    <?php echo e(\Carbon\Carbon::createFromFormat('Y-m', $laporan->bulan)->format('m')); ?>

                                </div>
                                <div class="min-w-0">
<h4 class="text-xs font-bold text-slate-800 dark:text-white truncate"><?php echo e(\Carbon\Carbon::createFromFormat('Y-m', $laporan->bulan)->translatedFormat('F Y')); ?></h4>
<p class="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5"><?php echo e($laporan->ekskul->nama_ekskul ?? 'Ekskul'); ?></p>
                                </div>
                            </div>
                            <span class="px-2.5 py-1 bg-gradient-to-r from-amber-100 to-yellow-100 dark:from-amber-950/30 dark:to-amber-900/30 text-amber-700 dark:text-amber-300 text-[10px] font-bold rounded-full border border-amber-200 dark:border-amber-800/50 shrink-0">Draft</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-8">
                            <div class="mx-auto w-16 h-16 rounded-2xl bg-sky-50 dark:bg-sky-950/30 flex items-center justify-center text-sky-300 dark:text-sky-600 border border-sky-100 dark:border-sky-800/50">
                                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477 4.5 1.253"/>
                                </svg>
                            </div>
                            <p class="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-3">Belum ada laporan</p>
                            <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-1">Laporan bulanan akan muncul di sini</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            </div>
        </div>

        <!-- RIGHT COLUMN -->
        <div class="space-y-6">

            <!-- MODERASI TESTIMONI & FAQ -->
            <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-sky-100 dark:border-neutral-800 shadow-lg shadow-sky-100/60 dark:shadow-sky-900/30 overflow-hidden animate-fade-up" style="animation-delay: .2s">
                <div class="px-6 py-5 flex justify-between items-center border-b border-sky-50 dark:border-neutral-800">
                    <div>
                        <h2 class="text-sm font-extrabold text-slate-900 dark:text-white">Testimoni & FAQ</h2>
                        <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">Moderasi kontribusi siswa</p>
                    </div>
                    <span class="text-[11px] font-semibold text-sky-600 bg-sky-50 border border-sky-100 px-3 py-1.5 rounded-full">Moderasi</span>
                </div>

                <div class="p-5 grid grid-cols-2 gap-3">
                    <a href="<?php echo e(route('pembina.testimoni.index')); ?>" class="p-3.5 bg-gradient-to-r from-sky-50 to-white dark:from-sky-950/30 dark:to-neutral-800/30 rounded-xl border border-sky-100 dark:border-neutral-700 hover:border-sky-300 dark:hover:border-neutral-600 transition">
                        <div class="flex items-center justify-between">
                            <span class="text-[11px] font-bold text-slate-600 dark:text-slate-400">Testimoni</span>
                            <?php if($testimoniPendingCount > 0): ?>
                                <span class="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                            <?php endif; ?>
                        </div>
                        <p class="text-2xl font-extrabold text-sky-700 dark:text-sky-400 mt-1"><?php echo e($testimoniPendingCount); ?></p>
                        <p class="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5"><?php echo e($testimoniPendingCount > 0 ? 'menunggu persetujuan' : 'tidak ada antrian'); ?></p>
                    </a>
                    <a href="<?php echo e(route('pembina.faq.index')); ?>" class="p-3.5 bg-gradient-to-r from-amber-50 to-white dark:from-amber-950/30 dark:to-amber-900/30 rounded-xl border border-amber-100 dark:border-amber-800/50 hover:border-amber-300 dark:hover:border-amber-800/50 transition">
                        <div class="flex items-center justify-between">
                            <span class="text-[11px] font-bold text-slate-600 dark:text-slate-400">FAQ</span>
                            <?php if($faqPendingCount > 0): ?>
                                <span class="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                            <?php endif; ?>
                        </div>
                        <p class="text-2xl font-extrabold text-amber-600 dark:text-amber-400 mt-1"><?php echo e($faqPendingCount); ?></p>
                        <p class="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5"><?php echo e($faqPendingCount > 0 ? 'menunggu jawaban' : 'tidak ada antrian'); ?></p>
                    </a>
                </div>

                <?php if($ekskuls->isNotEmpty()): ?>
                <div class="px-5 pb-5 space-y-4">
                    <form action="<?php echo e(route('pembina.testimoni.store')); ?>" method="POST" class="p-3.5 bg-gradient-to-r from-sky-50 to-white dark:from-sky-950/30 dark:to-neutral-800/30 rounded-xl border border-sky-100 dark:border-neutral-700 space-y-2.5">
                        <?php echo csrf_field(); ?>
                        <p class="text-[11px] font-bold text-slate-700">Tambah Testimoni</p>
                        <select name="ekskul_id" required
                            class="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-sky-100 dark:border-neutral-700 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-100 dark:focus:ring-sky-900/30 transition">
                            <?php $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ex->id); ?>"><?php echo e($ex->nama_ekskul); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="grid grid-cols-2 gap-2">
                            <input type="text" name="nama" required placeholder="Nama"
                                class="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-sky-100 dark:border-neutral-700 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-100 dark:focus:ring-sky-900/30 transition">
                            <input type="text" name="kelas" placeholder="Kelas (opsional)"
                                class="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-sky-100 dark:border-neutral-700 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-100 dark:focus:ring-sky-900/30 transition">
                        </div>
                        <textarea name="quote" rows="2" required placeholder="Isi testimoni..."
                            class="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-sky-100 dark:border-neutral-700 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-100 dark:focus:ring-sky-900/30 transition"></textarea>
                        <button type="submit" class="px-3.5 py-2 bg-sky-600 hover:bg-sky-700 text-white text-[10px] font-bold rounded-xl transition">Simpan Testimoni</button>
                    </form>

                    <form action="<?php echo e(route('pembina.faq.store')); ?>" method="POST" class="p-3.5 bg-gradient-to-r from-amber-50 to-white dark:from-amber-950/30 dark:to-amber-900/30 rounded-xl border border-amber-100 dark:border-amber-800/50 space-y-2.5">
                        <?php echo csrf_field(); ?>
                        <p class="text-[11px] font-bold text-slate-700">Tambah FAQ</p>
                        <select name="ekskul_id" required
                            class="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-amber-100 dark:border-amber-800/50 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-100 dark:focus:ring-amber-900/30 transition">
                            <?php $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ex->id); ?>"><?php echo e($ex->nama_ekskul); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="text" name="pertanyaan" required placeholder="Pertanyaan umum..."
                            class="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-amber-100 dark:border-amber-800/50 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-100 dark:focus:ring-amber-900/30 transition">
                        <textarea name="jawaban" rows="2" required placeholder="Jawaban..."
                            class="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-amber-100 dark:border-amber-800/50 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-100 dark:focus:ring-amber-900/30 transition"></textarea>
                        <button type="submit" class="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-white text-[10px] font-bold rounded-xl transition">Simpan FAQ</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>

            <!-- PENDAFTARAN SISWA -->
            <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-sky-100 dark:border-neutral-800 shadow-lg shadow-sky-100/60 dark:shadow-sky-900/30 overflow-hidden animate-fade-up" style="animation-delay: .25s">
                <div class="px-6 py-5 flex justify-between items-center border-b border-sky-50 dark:border-neutral-800">
                    <div>
                        <h2 class="text-sm font-extrabold text-slate-900 dark:text-white">Pendaftaran Siswa</h2>
                        <p class="text-[11px] text-slate-400 mt-0.5">Menunggu verifikasi</p>
                    </div>
                    <span class="text-[11px] font-semibold text-amber-600 bg-amber-50 border border-amber-100 px-3 py-1.5 rounded-full"><?php echo e(count($pendaftaranPending ?? [])); ?> Pending</span>
                </div>

                <?php if(isset($pendaftaranPending) && count($pendaftaranPending) > 0): ?>
                    <div class="p-5">
                        <?php $__currentLoopData = $pendaftaranPending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-3.5 bg-gradient-to-r from-sky-50 to-white dark:from-sky-950/30 dark:to-neutral-800/30 rounded-xl flex items-center justify-between mb-3 border border-sky-100 dark:border-neutral-700 gap-3 hover:border-sky-200 dark:hover:border-neutral-600 transition">
                            <div class="flex items-center gap-3 min-w-0">
                                <div class="w-9 h-9 rounded-full bg-gradient-to-br from-sky-400 to-blue-500 text-white font-extrabold flex items-center justify-center text-xs uppercase shadow-md shadow-sky-200 dark:shadow-sky-900/30 shrink-0">
                                    <?php echo e(substr($item->siswa->nama ?? 'A', 0, 1)); ?>

                                </div>
                                <div class="min-w-0">
<h4 class="text-xs font-bold text-slate-800 dark:text-white truncate"><?php echo e($item->siswa->nama ?? '-'); ?></h4>
<p class="text-[10px] text-slate-400 dark:text-slate-500"><?php echo e($item->siswa->kelas->nama ?? '-'); ?></p>
                                </div>
                            </div>
                            <span class="px-2.5 py-1 bg-gradient-to-r from-amber-100 to-yellow-100 dark:from-amber-950/30 dark:to-amber-900/30 text-amber-700 dark:text-amber-300 text-[10px] font-bold rounded-full border border-amber-200 dark:border-amber-800/50 shrink-0">Pending</span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-3 bg-gradient-to-r from-sky-50 to-blue-50 rounded-xl border border-sky-200">
                            <p class="text-xs text-sky-700">Verifikasi pendaftaran dilakukan secara manual oleh ketua ekskul.</p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-10">
                        <div class="mx-auto w-16 h-16 rounded-2xl bg-sky-50 dark:bg-sky-950/30 flex items-center justify-center text-sky-300 dark:text-sky-600 border border-sky-100 dark:border-sky-800/50">
                            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                        </div>
                        <p class="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-3">Tidak ada pendaftaran baru</p>
                        <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-1">Semua pendaftaran sudah diproses</p>
                    </div>
                <?php endif; ?>
            </div>

            </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pembina.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Soul\resources\views/pembina/dashboard.blade.php ENDPATH**/ ?>