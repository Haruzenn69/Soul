<?php $__env->startSection('title', 'Detail Akun – ' . ($user->siswa?->nama ?? $user->pembina?->nama ?? $user->username ?? $user->email)); ?>

<?php $__env->startSection('content'); ?>
<?php
    $backUrl = request()->headers->get('referer');
    if (! $backUrl || parse_url($backUrl, PHP_URL_HOST) !== request()->getHost()) {
        $backUrl = route('kesiswaan.users.index');
    }

    $histories = $user->siswa?->profileHistories ?? $user->pembina?->profileHistories ?? collect();

    $statusLabels = [
        'diterima'   => 'Aktif',
        'pending'    => 'Pending',
        'ditolak'    => 'Ditolak',
        'nonaktif'   => 'Nonaktif',
        'peringatan' => 'Peringatan',
        'keluar'     => 'Keluar',
    ];
    $totalPresensi = $presensi ? (int) $presensi->sum() : 0;
    $hadirPresensi = $presensi ? (int) ($presensi['hadir'] ?? 0) : 0;
    $persenHadir = $totalPresensi > 0 ? round(($hadirPresensi / $totalPresensi) * 100) : null;
?>

<div class="space-y-5 animate-fade-up">
    
    <a href="<?php echo e($backUrl); ?>"
       class="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-2xl transition">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
        Kembali
    </a>

    
    <div class="bg-white p-6 rounded-3xl border border-sky-100 shadow-sm">
        <div class="flex flex-col md:flex-row items-start md:items-center gap-5">
            <div class="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-slate-100 flex items-center justify-center overflow-hidden shrink-0 border-2 border-sky-200">
                <?php if($user->siswa?->foto_url): ?>
                    <img src="<?php echo e($user->siswa->foto_url); ?>" alt="<?php echo e($user->siswa->nama); ?>" class="w-full h-full object-cover">
                <?php elseif($user->pembina?->foto_url): ?>
                    <img src="<?php echo e($user->pembina->foto_url); ?>" alt="<?php echo e($user->pembina->nama); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <span class="text-2xl font-black text-sky-600">
                        <?php echo e(strtoupper(substr($user->siswa?->nama ?? $user->pembina?->nama ?? $user->username ?? $user->email ?? 'U', 0, 2))); ?>

                    </span>
                <?php endif; ?>
            </div>

            <div class="flex-1 min-w-0">
                <div class="flex flex-wrap items-center gap-2 mb-2">
                    <h2 class="text-xl font-extrabold text-slate-900 truncate">
                        <?php echo e($user->siswa?->nama ?? $user->pembina?->nama ?? $user->username ?? $user->email); ?>

                    </h2>
                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[10px] font-bold
                        <?php if($user->role === 'siswa'): ?> bg-sky-100 text-sky-700 border border-sky-200
                        <?php elseif($user->role === 'pembina'): ?> bg-emerald-100 text-emerald-700 border border-emerald-200
                        <?php elseif($user->role === 'kesiswaan'): ?> bg-indigo-100 text-indigo-700 border border-indigo-200
                        <?php else: ?> bg-amber-100 text-amber-700 border border-amber-200 <?php endif; ?>">
                        <?php echo e(ucfirst($user->role)); ?>

                    </span>
                    <?php if($user->siswa?->jabatan === 'ketua'): ?>
                        <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 whitespace-nowrap">
                            <svg class="w-3 h-3" viewBox="0 0 24 24" fill="currentColor"><path d="M2 19l2-9 5 5 3-8 3 8 5-5 2 9H2z"/></svg> Ketua
                        </span>
                    <?php endif; ?>
                    <?php if($user->siswa?->status): ?>
                        <span class="inline-flex items-center px-2.5 py-1 rounded-xl text-[10px] font-bold whitespace-nowrap
                            <?php if($user->siswa->status === 'aktif'): ?> bg-emerald-100 text-emerald-700 border border-emerald-200
                            <?php elseif($user->siswa->status === 'menunggu_penempatan'): ?> bg-amber-100 text-amber-700 border border-amber-200
                            <?php else: ?> bg-slate-100 text-slate-500 border border-slate-200 <?php endif; ?>">
                            <?php echo e(['aktif' => 'Aktif', 'menunggu_penempatan' => 'Menunggu Penempatan', 'nonaktif' => 'Alumni / Nonaktif'][$user->siswa->status] ?? ucfirst($user->siswa->status)); ?>

                        </span>
                    <?php endif; ?>
                </div>

                <dl class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                    <div>
                        <dt class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Username</dt>
                        <dd class="text-slate-900 font-medium mt-0.5 break-all"><?php echo e(filled($user->username) ? $user->username : '—'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Email</dt>
                        <dd class="text-slate-900 font-medium mt-0.5 break-all"><?php echo e(filled($user->email) ? $user->email : '—'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Role</dt>
                        <dd class="text-slate-900 font-medium mt-0.5 capitalize"><?php echo e($user->role); ?></dd>
                    </div>
                    <div>
                        <dt class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Status Akun</dt>
                        <dd class="text-slate-900 font-medium mt-0.5">
                            <span class="inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] font-bold
                                <?php if($user->is_active): ?> bg-emerald-50 text-emerald-700 border border-emerald-200
                                <?php else: ?> bg-rose-50 text-rose-600 border border-rose-200 <?php endif; ?>">
                                <?php echo e($user->is_active ? 'Aktif' : 'Nonaktif'); ?>

                            </span>
                        </dd>
                    </div>
                </dl>

                
                <div class="flex flex-wrap gap-2 mt-4">
                    <?php if($user->role === 'siswa'): ?>
                        <div class="px-3 py-2 rounded-2xl bg-sky-50 border border-sky-100">
                            <div class="text-[10px] font-bold text-sky-500 uppercase tracking-wider">Ekskul Aktif</div>
                            <div class="text-sm font-extrabold text-slate-900"><?php echo e($pendaftaranAktif); ?></div>
                        </div>
                        <div class="px-3 py-2 rounded-2xl bg-slate-50 border border-slate-100">
                            <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Kelas</div>
                            <div class="text-sm font-extrabold text-slate-900"><?php echo e($user->siswa?->kelas?->nama ?? '—'); ?></div>
                        </div>
                        <?php if($persenHadir !== null): ?>
                            <div class="px-3 py-2 rounded-2xl bg-emerald-50 border border-emerald-100">
                                <div class="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">Kehadiran</div>
                                <div class="text-sm font-extrabold text-slate-900"><?php echo e($persenHadir); ?>% <span class="text-[10px] font-semibold text-slate-400">(<?php echo e($hadirPresensi); ?>/<?php echo e($totalPresensi); ?>)</span></div>
                            </div>
                        <?php endif; ?>
                    <?php elseif($user->role === 'pembina'): ?>
                        <div class="px-3 py-2 rounded-2xl bg-emerald-50 border border-emerald-100">
                            <div class="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">Ekskul Dibina</div>
                            <div class="text-sm font-extrabold text-slate-900"><?php echo e($pendaftaranAktif); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="flex flex-col sm:flex-row gap-2 shrink-0">
                <?php if($user->role === 'admin' && auth()->user()->role !== 'admin'): ?>
                    <span class="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-[11px] text-slate-400 italic">
                        Dikelola Admin
                    </span>
                <?php else: ?>
                    <a href="<?php echo e(route('kesiswaan.users.edit', $user)); ?>"
                       class="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-xl transition text-xs">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                        Edit Akun
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="bg-white rounded-3xl border border-sky-100 shadow-sm overflow-hidden">
        <div class="border-b border-slate-100 overflow-x-auto">
            <nav class="flex gap-1 px-4 -mb-px min-w-max" aria-label="Tabs">
                <button type="button" data-tab="profil" class="tab-btn px-4 py-3 text-sm font-bold rounded-t-2xl border-b-2 border-amber-500 text-amber-600 bg-amber-50 whitespace-nowrap">Profil Lengkap</button>
                <?php if($user->role === 'siswa'): ?>
                    <button type="button" data-tab="ekskul" class="tab-btn px-4 py-3 text-sm font-bold rounded-t-2xl border-b-2 border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200 whitespace-nowrap">Keanggotaan Ekskul</button>
                    <button type="button" data-tab="riwayat" class="tab-btn px-4 py-3 text-sm font-bold rounded-t-2xl border-b-2 border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200 whitespace-nowrap">Riwayat Jabatan</button>
                    <button type="button" data-tab="pengajuan" class="tab-btn px-4 py-3 text-sm font-bold rounded-t-2xl border-b-2 border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200 whitespace-nowrap">Pengajuan Keluar</button>
                    <button type="button" data-tab="kelas" class="tab-btn px-4 py-3 text-sm font-bold rounded-t-2xl border-b-2 border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200 whitespace-nowrap">Riwayat Kelas</button>
                    <button type="button" data-tab="nilai" class="tab-btn px-4 py-3 text-sm font-bold rounded-t-2xl border-b-2 border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200 whitespace-nowrap">Nilai</button>
                <?php elseif($user->role === 'pembina'): ?>
                    <button type="button" data-tab="ekskul" class="tab-btn px-4 py-3 text-sm font-bold rounded-t-2xl border-b-2 border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200 whitespace-nowrap">Ekskul Dibina</button>
                <?php endif; ?>
                <button type="button" data-tab="riwayat-profil" class="tab-btn px-4 py-3 text-sm font-bold rounded-t-2xl border-b-2 border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200 whitespace-nowrap">Riwayat Profil</button>
            </nav>
        </div>

        <div class="p-6">
            
            <div id="tab-profil" class="tab-panel space-y-6">
                <h3 class="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                    <svg class="w-4 h-4 text-sky-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                    Identitas
                </h3>
                <dl class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                    <?php if($user->role === 'siswa' && $user->siswa): ?>
                        <?php $s = $user->siswa; ?>
                        <?php $__currentLoopData = [
                            'NIS' => $s->nis,
                            'Nama Lengkap' => $s->nama,
                            'Tempat Lahir' => $s->tempat_lahir,
                            'Tanggal Lahir' => $s->tanggal_lahir?->isoFormat('DD MMMM YYYY'),
                            'Jenis Kelamin' => $s->jenis_kelamin ? ucfirst($s->jenis_kelamin) : null,
                            'Agama' => $s->agama,
                            'Alamat' => $s->alamat,
                            'No. Telepon' => $s->no_telp,
                            'Email' => $s->email,
                            'MedSos' => $s->medsos,
                            'Jabatan' => ucfirst($s->jabatan ?? 'siswa'),
                            'Angkatan' => $s->angkatan,
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <dt class="text-[10px] font-bold text-slate-400 uppercase tracking-wider"><?php echo e($label); ?></dt>
                                <dd class="text-slate-900 font-medium mt-0.5 break-all"><?php echo e(filled($value) ? $value : '—'); ?></dd>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <h3 class="text-sm font-extrabold text-slate-900 flex items-center gap-2 mt-6 pt-4 border-t border-slate-100 sm:col-span-2">
                            <svg class="w-4 h-4 text-sky-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                            Data Akademik
                        </h3>
                        <?php
                            $akademik = [
                                'Kelas' => $s->kelas?->nama,
                                'Tingkat' => $s->kelas?->tingkat ? strtoupper($s->kelas->tingkat) : null,
                                'Jurusan' => $s->kelas?->jurusan_label ?? $s->kelas?->jurusan,
                                'Tahun Ajaran' => $s->kelas?->tahunAjaran?->nama,
                            ];
                        ?>
                        <?php $__currentLoopData = $akademik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <dt class="text-[10px] font-bold text-slate-400 uppercase tracking-wider"><?php echo e($label); ?></dt>
                                <dd class="text-slate-900 font-medium mt-0.5"><?php echo e(filled($value) ? $value : '—'); ?></dd>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php elseif($user->role === 'pembina' && $user->pembina): ?>
                        <?php $p = $user->pembina; ?>
                        <?php $__currentLoopData = [
                            'NIP' => $p->nip,
                            'Nama Lengkap' => $p->nama,
                            'Tempat Lahir' => $p->tempat_lahir,
                            'Tanggal Lahir' => $p->tanggal_lahir?->isoFormat('DD MMMM YYYY'),
                            'Jenis Kelamin' => $p->jenis_kelamin ? ucfirst($p->jenis_kelamin) : null,
                            'Agama' => $p->agama,
                            'No. Telepon' => $p->no_telp,
                            'Email' => $p->email,
                            'MedSos' => $p->medsos,
                            'Alamat' => $p->alamat,
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <dt class="text-[10px] font-bold text-slate-400 uppercase tracking-wider"><?php echo e($label); ?></dt>
                                <dd class="text-slate-900 font-medium mt-0.5 break-all"><?php echo e(filled($value) ? $value : '—'); ?></dd>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p class="text-slate-400 text-sm">Data profil belum lengkap.</p>
                    <?php endif; ?>
                </dl>
            </div>

            
            <?php if($user->role === 'siswa'): ?>
            <div id="tab-ekskul" class="tab-panel hidden space-y-6">
                <?php if($ekskuls && $ekskuls->isNotEmpty()): ?>
                    <?php $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $pendaftaran = $user->siswa?->pendaftarans->firstWhere('ekskul_id', $ek->id);
                            $isKetua = ($user->siswa?->jabatan === 'ketua') && $pendaftaran;
                        ?>
                        <div class="rounded-2xl border <?php echo e($isKetua ? 'border-sky-300 bg-sky-50/50 ring-2 ring-sky-200' : 'border-slate-100'); ?> p-5 relative">
                            <?php if($isKetua): ?>
                                <span class="absolute -top-2 -right-2 px-2 py-0.5 bg-sky-100 text-sky-700 text-[10px] font-bold rounded-full">KETUA EKSKUL INI</span>
                            <?php endif; ?>
                            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                                <div class="flex items-center gap-3">
                                    <div class="w-11 h-11 rounded-2xl overflow-hidden bg-slate-100 shrink-0 flex items-center justify-center font-black text-sky-600 uppercase text-xs">
                                        <?php if($ek->logo): ?>
                                            <img src="<?php echo e(asset('storage/' . $ek->logo)); ?>" alt="<?php echo e($ek->nama_ekskul); ?>" class="w-full h-full object-cover">
                                        <?php else: ?>
                                            <?php echo e(strtoupper(substr($ek->nama_ekskul, 0, 2))); ?>

                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <h4 class="font-extrabold text-slate-900"><?php echo e($ek->nama_ekskul); ?></h4>
                                        <p class="text-xs text-slate-400 mt-0.5"><?php echo e($ek->kategori ?? '-'); ?><?php echo e($ek->pembina ? ' · Pembina: ' . $ek->pembina->nama : ''); ?><?php echo e($ek->pelatih ? ' · Pelatih: ' . $ek->pelatih->nama : ''); ?></p>
                                    </div>
                                </div>
                                <div class="flex flex-wrap items-center gap-2">
                                    <span class="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200"><?php echo e($statusLabels[$pendaftaran?->status] ?? ucfirst($pendaftaran?->status ?? 'Aktif')); ?></span>
                                    <span class="px-2.5 py-1 rounded-xl bg-slate-100 text-slate-600 text-[10px] font-bold">Daftar: <?php echo e($pendaftaran?->tanggal_daftar?->format('d M Y') ?? '-'); ?></span>
                                    <a href="<?php echo e(route('kesiswaan.ekskuls.show', $ek)); ?>"
                                       class="px-2.5 py-1 rounded-xl bg-sky-50 text-sky-700 border border-sky-100 text-[10px] font-bold hover:bg-sky-100 transition">
                                        Lihat Ekskul &rarr;
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="text-center py-10 text-slate-400">
                        <p class="text-xs font-semibold">Belum bergabung ekskul manapun.</p>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            
            <?php if($user->role === 'pembina'): ?>
            <div id="tab-ekskul" class="tab-panel hidden space-y-6">
                <?php if($ekskuls && $ekskuls->isNotEmpty()): ?>
                    <?php $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="rounded-2xl border border-slate-100 p-5">
                            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                                <div>
                                    <h4 class="font-extrabold text-slate-900"><?php echo e($ek->nama_ekskul); ?></h4>
                                    <p class="text-xs text-slate-400 mt-0.5"><?php echo e($ek->kategori ?? '-'); ?><?php echo e($ek->pelatih ? ' · Pelatih: ' . $ek->pelatih->nama : ''); ?></p>
                                </div>
                                <div class="flex flex-wrap items-center gap-2">
                                    <span class="px-2.5 py-1 rounded-xl <?php echo e($ek->status ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-500 border border-slate-200'); ?> text-[10px] font-bold"><?php echo e($ek->status ? 'Aktif' : 'Nonaktif'); ?></span>
                                    <span class="px-2.5 py-1 rounded-xl bg-sky-50 text-sky-700 text-[10px] font-bold border border-sky-100"><?php echo e($ek->pendaftarans()->where('status', 'diterima')->count()); ?> Anggota</span>
                                    <a href="<?php echo e(route('kesiswaan.ekskuls.show', $ek)); ?>"
                                       class="px-2.5 py-1 rounded-xl bg-sky-100 text-sky-700 text-[10px] font-bold hover:bg-sky-200 transition">
                                        Lihat Ekskul &rarr;
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="text-center py-10 text-slate-400">
                        <p class="text-xs font-semibold">Belum membina ekskul manapun.</p>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            
            <?php if($user->role === 'siswa' && $user->siswa): ?>
            <div id="tab-riwayat" class="tab-panel hidden space-y-4">
                <?php $riwayat = $user->siswa->riwayatJabatans()->with('ekskul')->latest('mulai')->latest('id')->get(); ?>
                <?php if($riwayat->isNotEmpty()): ?>
                    <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white border border-slate-100 rounded-2xl p-4 <?php echo e($r->isActive() ? 'ring-2 ring-amber-200 bg-amber-50/30' : ''); ?>">
                            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                                <div>
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="px-2.5 py-1 rounded-xl text-[10px] font-bold
                                            <?php if($r->isActive()): ?> bg-amber-100 text-amber-800 border border-amber-300
                                            <?php elseif($r->alasan_selesai === 'diganti'): ?> bg-sky-100 text-sky-700 border border-sky-200
                                            <?php elseif($r->alasan_selesai === 'dicopot'): ?> bg-rose-100 text-rose-600 border border-rose-200
                                            <?php elseif($r->alasan_selesai === 'keluar'): ?> bg-violet-100 text-violet-700 border border-violet-200
                                            <?php else: ?> bg-slate-100 text-slate-500 border border-slate-200 <?php endif; ?>">
                                            <?php echo e($r->isActive() ? 'Berlangsung' : ucfirst($r->alasan_selesai ?? 'selesai')); ?>

                                        </span>
                                        <?php if($r->isActive()): ?>
                                            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" title="Periode aktif"></span>
                                        <?php endif; ?>
                                    </div>
                                    <p class="font-bold text-slate-900">Ketua Ekskul <?php echo e($r->ekskul->nama_ekskul ?? '-'); ?></p>
                                    <p class="text-sm text-slate-500 mt-0.5"><?php echo e($r->periodeText()); ?> · <?php echo e($r->durasiHari()); ?> hari</p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="text-center py-8 text-slate-400">
                        <svg class="w-12 h-12 mx-auto text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        <p class="mt-2 font-medium">Belum pernah menjabat Ketua.</p>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            
            <?php if($user->role === 'siswa' && $user->siswa): ?>
            <div id="tab-pengajuan" class="tab-panel hidden space-y-4">
                <?php $pengajuan = $user->siswa->pengajuanKeluars()->with('ekskul')->latest()->get(); ?>
                <?php if($pengajuan->isNotEmpty()): ?>
                    <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white border border-slate-100 rounded-2xl p-4">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h5 class="font-bold text-slate-900">Pengajuan Keluar Ekskul</h5>
                                    <p class="text-xs text-slate-400 mt-0.5"><?php echo e($p->ekskul->nama_ekskul ?? '-'); ?> · <?php echo e($p->tanggal_pengajuan ? \Carbon\Carbon::parse($p->tanggal_pengajuan)->isoFormat('DD MMM Y') : '-'); ?></p>
                                </div>
                                <span class="px-2.5 py-1 rounded-xl text-[10px] font-bold
                                    <?php if($p->status === 'pending'): ?> bg-amber-50 text-amber-700 border border-amber-200
                                    <?php elseif($p->status === 'diterima'): ?> bg-emerald-50 text-emerald-700 border border-emerald-200
                                    <?php else: ?> bg-rose-50 text-rose-600 border border-rose-200 <?php endif; ?>">
                                    <?php echo e(ucfirst($p->status)); ?>

                                </span>
                            </div>
                            <p class="text-sm text-slate-600 mt-2"><?php echo e($p->alasan); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="text-center py-8 text-slate-400">
                        <svg class="w-12 h-12 mx-auto text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                        <p class="mt-2 font-medium">Belum ada pengajuan keluar.</p>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            
            <?php if($user->role === 'siswa' && $user->siswa): ?>
            <div id="tab-kelas" class="tab-panel hidden space-y-4">
                <?php $riwayatKelas = $user->siswa->classHistories; ?>
                <?php if($riwayatKelas->isNotEmpty()): ?>
                    <div class="overflow-x-auto rounded-2xl border border-slate-100">
                        <table class="w-full min-w-[560px] text-left text-xs">
                            <thead class="bg-slate-50 text-[11px] uppercase tracking-wide text-slate-500">
                                <tr>
                                    <th class="px-4 py-3 font-bold">Tahun Ajaran</th>
                                    <th class="px-4 py-3 font-bold">Kelas Asal</th>
                                    <th class="px-4 py-3 font-bold">Kelas Tujuan</th>
                                    <th class="px-4 py-3 font-bold">Keterangan</th>
                                    <th class="px-4 py-3 font-bold">Tanggal</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <?php $__currentLoopData = $riwayatKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-3 font-semibold text-slate-700"><?php echo e($history->tahun_ajaran); ?></td>
                                        <td class="px-4 py-3 text-slate-600"><?php echo e($history->kelas_asal); ?></td>
                                        <td class="px-4 py-3 text-slate-600"><?php echo e($history->kelas_tujuan ?? 'Lulus / Alumni'); ?></td>
                                        <td class="px-4 py-3 text-slate-600"><?php echo e(['kenaikan' => 'Naik kelas otomatis', 'penempatan' => 'Penempatan oleh kesiswaan', 'kelulusan' => 'Lulus dan diarsipkan'][$history->jenis] ?? $history->jenis); ?></td>
                                        <td class="px-4 py-3 text-slate-500"><?php echo e($history->diproses_pada?->format('d-m-Y H:i') ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8 text-slate-400">
                        <svg class="w-12 h-12 mx-auto text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                        <p class="mt-2 font-medium">Belum ada riwayat perpindahan atau kelulusan kelas.</p>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            
            <?php if($user->role === 'siswa'): ?>
            <div id="tab-nilai" class="tab-panel hidden space-y-4">
                <?php if($penilaians->isNotEmpty()): ?>
                    <div class="overflow-x-auto rounded-2xl border border-slate-100">
                        <table class="w-full min-w-[620px] text-left text-xs">
                            <thead class="bg-slate-50 text-[11px] uppercase tracking-wide text-slate-500">
                                <tr>
                                    <th class="px-4 py-3 font-bold">Periode</th>
                                    <th class="px-4 py-3 font-bold">Ekskul</th>
                                    <th class="px-4 py-3 text-center font-bold">Kehadiran</th>
                                    <th class="px-4 py-3 text-center font-bold">Nilai Akhir</th>
                                    <th class="px-4 py-3 text-center font-bold">Predikat</th>
                                    <th class="px-4 py-3 font-bold">Pembina</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <?php $__currentLoopData = $penilaians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-slate-50/70">
                                        <td class="px-4 py-3 font-semibold text-slate-700"><?php echo e($penilaian->periode); ?></td>
                                        <td class="px-4 py-3 text-slate-700"><?php echo e($penilaian->pendaftaran?->ekskul?->nama_ekskul ?? '-'); ?></td>
                                        <td class="px-4 py-3 text-center text-slate-600"><?php echo e(number_format((float) $penilaian->persentase_kehadiran, 1)); ?>%</td>
                                        <td class="px-4 py-3 text-center font-extrabold text-slate-900"><?php echo e(number_format((float) $penilaian->nilai_akhir, 2)); ?></td>
                                        <td class="px-4 py-3 text-center"><span class="inline-flex items-center justify-center w-7 h-7 rounded-lg border font-extrabold <?php echo e(\App\Models\Penilaian::warnaPredikat((string) $penilaian->predikat)); ?>"><?php echo e($penilaian->predikat ?? '-'); ?></span></td>
                                        <td class="px-4 py-3 text-slate-600"><?php echo e($penilaian->penilai?->nama ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="py-8 text-center text-slate-400">
                        <p class="font-medium">Belum ada nilai ekskul yang diterbitkan.</p>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            
            <div id="tab-riwayat-profil" class="tab-panel hidden space-y-4">
                <?php if($histories->isNotEmpty()): ?>
                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white border border-slate-100 rounded-2xl p-4">
                            <div class="flex justify-between items-start mb-2">
                                <p class="text-xs font-bold text-slate-400 uppercase tracking-wider"><?php echo e($riwayat->field); ?></p>
                                <span class="text-[10px] text-slate-500"><?php echo e($riwayat->created_at->isoFormat('DD MMM YYYY HH:mm')); ?></span>
                            </div>
                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div class="p-3 bg-rose-50 rounded-xl border border-rose-100">
                                    <dt class="text-[10px] font-bold text-rose-600 uppercase tracking-wider">Sebelum</dt>
                                    <dd class="text-slate-700 font-medium mt-1 break-all"><?php echo e(filled($riwayat->old_value) ? $riwayat->old_value : '—'); ?></dd>
                                </div>
                                <div class="p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                                    <dt class="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">Sesudah</dt>
                                    <dd class="text-slate-700 font-medium mt-1 break-all"><?php echo e(filled($riwayat->new_value) ? $riwayat->new_value : '—'); ?></dd>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="text-center py-8 text-slate-400">
                        <svg class="w-12 h-12 mx-auto text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 012-2h2a2 2 0 012 2v2H9V5zm1 8l2 2 4-4"/></svg>
                        <p class="mt-2 font-medium">Belum ada riwayat perubahan profil.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('.tab-btn');
    const panels = document.querySelectorAll('.tab-panel');

    tabs.forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.dataset.tab;
            tabs.forEach(b => {
                b.classList.remove('border-amber-500', 'text-amber-600', 'bg-amber-50');
                b.classList.add('border-transparent', 'text-slate-400');
            });
            btn.classList.add('border-amber-500', 'text-amber-600', 'bg-amber-50');
            btn.classList.remove('border-transparent', 'text-slate-400');

            panels.forEach(p => p.classList.toggle('hidden', p.id !== 'tab-' + target));
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kesiswaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Soul\resources\views/kesiswaan/users/show.blade.php ENDPATH**/ ?>