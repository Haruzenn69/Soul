<?php $__env->startSection('title', 'Data Kelas'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $sort = $sort ?? 'nama';
    $direction = $direction ?? 'asc';

    $sortLink = function (string $column) use ($sort, $direction) {
        $nextDirection = $sort === $column && $direction === 'asc' ? 'desc' : 'asc';
        return request()->fullUrlWithQuery(['sort' => $column, 'direction' => $nextDirection, 'page' => null]);
    };

    $sortIcon = function (string $column) use ($sort, $direction) {
        if ($sort !== $column) {
            return 'M8 9l4-4 4 4M8 15l4 4 4-4';
        }
        return $direction === 'asc' ? 'M8 15l4 4 4-4' : 'M8 9l4-4 4 4';
    };

    $hasFilter = request()->filled(['q', 'tahun_ajaran_id']) || request()->filled('sort');
?>

<div class="space-y-5 animate-fade-up">

    
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sky-400 via-blue-400 to-blue-600 p-6 md:p-8 text-white shadow-xl shadow-sky-200">
        
        <div class="absolute inset-0 pointer-events-none">
            <div class="absolute -bottom-24 -left-10 w-72 h-72 rounded-full bg-white/10 blur-3xl"></div>
            <div class="absolute -top-24 -right-10 w-72 h-72 rounded-full bg-white/10 blur-3xl"></div>
        </div>

        
        <div class="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
                <h1 class="text-2xl md:text-3xl font-extrabold tracking-tight leading-tight text-white">
                    Data Kelas
                </h1>
                <p class="text-xs text-white/80 mt-1.5 max-w-xl leading-relaxed">
                    Kelola data rombongan belajar per tingkat dan tahun ajaran. Pantau dan buka detail siswa di masing-masing kelas.
                </p>
            </div>

            <div class="flex gap-2.5 shrink-0 items-center flex-wrap">
                <?php if($tahunAjarans->isEmpty()): ?>
                    <span class="px-4 py-2.5 bg-amber-500/20 border border-amber-300/30 text-amber-100 rounded-2xl text-xs font-bold flex items-center gap-2">
                        <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                        Belum ada tahun ajaran
                    </span>
                <?php else: ?>
                    <button type="button" onclick="document.getElementById('modal-create').showModal()"
                            class="inline-flex items-center justify-center gap-2 px-5 py-3 bg-white text-sky-700 font-bold text-xs rounded-2xl shadow-lg shadow-sky-900/10 hover:bg-sky-50 hover:-translate-y-0.5 transition-all">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                        Tambah Kelas
                    </button>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="relative mt-6 pt-5 border-t border-white/15">
            <div class="text-[11px] font-bold text-white/75 uppercase tracking-wider mb-2.5">
                Filter Tingkatan Kelas:
            </div>
            <div class="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                <?php
                    $tabAllUrl = route('kesiswaan.kelas.index', array_filter(['q' => request('q'), 'tahun_ajaran_id' => request('tahun_ajaran_id')]));
                    $tabXUrl = route('kesiswaan.kelas.index', array_filter(['tingkat' => 'x', 'q' => request('q'), 'tahun_ajaran_id' => request('tahun_ajaran_id')]));
                    $tabXIUrl = route('kesiswaan.kelas.index', array_filter(['tingkat' => 'xi', 'q' => request('q'), 'tahun_ajaran_id' => request('tahun_ajaran_id')]));
                    $tabXIIUrl = route('kesiswaan.kelas.index', array_filter(['tingkat' => 'xii', 'q' => request('q'), 'tahun_ajaran_id' => request('tahun_ajaran_id')]));
                ?>

                
                <a href="<?php echo e($tabAllUrl); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap <?php echo e(empty($activeTingkat) ? 'bg-white text-sky-700 shadow-md shadow-sky-900/15' : 'bg-white/10 backdrop-blur border border-white/20 text-white hover:bg-white/20'); ?>">
                    <span>Semua Tingkat</span>
                    <span class="px-2 py-0.5 rounded-full text-[11px] <?php echo e(empty($activeTingkat) ? 'bg-sky-100 text-sky-700 font-bold' : 'bg-white/15 text-white'); ?>">
                        <?php echo e($counts['all']); ?>

                    </span>
                </a>

                
                <a href="<?php echo e($tabXUrl); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap <?php echo e($activeTingkat === 'x' ? 'bg-white text-sky-700 shadow-md shadow-sky-900/15' : 'bg-white/10 backdrop-blur border border-white/20 text-white hover:bg-white/20'); ?>">
                    <span>Kelas 10 (X)</span>
                    <span class="px-2 py-0.5 rounded-full text-[11px] <?php echo e($activeTingkat === 'x' ? 'bg-sky-100 text-sky-700 font-bold' : 'bg-white/15 text-white'); ?>">
                        <?php echo e($counts['x']); ?>

                    </span>
                </a>

                
                <a href="<?php echo e($tabXIUrl); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap <?php echo e($activeTingkat === 'xi' ? 'bg-white text-sky-700 shadow-md shadow-sky-900/15' : 'bg-white/10 backdrop-blur border border-white/20 text-white hover:bg-white/20'); ?>">
                    <span>Kelas 11 (XI)</span>
                    <span class="px-2 py-0.5 rounded-full text-[11px] <?php echo e($activeTingkat === 'xi' ? 'bg-sky-100 text-sky-700 font-bold' : 'bg-white/15 text-white'); ?>">
                        <?php echo e($counts['xi']); ?>

                    </span>
                </a>

                
                <a href="<?php echo e($tabXIIUrl); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap <?php echo e($activeTingkat === 'xii' ? 'bg-white text-sky-700 shadow-md shadow-sky-900/15' : 'bg-white/10 backdrop-blur border border-white/20 text-white hover:bg-white/20'); ?>">
                    <span>Kelas 12 (XII)</span>
                    <span class="px-2 py-0.5 rounded-full text-[11px] <?php echo e($activeTingkat === 'xii' ? 'bg-sky-100 text-sky-700 font-bold' : 'bg-white/15 text-white'); ?>">
                        <?php echo e($counts['xii']); ?>

                    </span>
                </a>
            </div>
        </div>
    </div>

    
    <?php if($errors->any()): ?>
        <div class="p-4 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold rounded-2xl shadow-sm">
            <ul class="list-disc list-inside space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <?php
        $selectedTa = $tahunAjarans->firstWhere('id', request('tahun_ajaran_id'));
        $activeFilterCount = (request()->filled('tahun_ajaran_id') ? 1 : 0) + (request()->filled('tingkat') ? 1 : 0);
        $hasActiveFilter = request()->filled('q') || $activeFilterCount > 0;
    ?>

    <div x-data="{ openFilter: false }" class="space-y-3">
        <form method="GET" action="<?php echo e(route('kesiswaan.kelas.index')); ?>" class="bg-white p-4 rounded-3xl border border-sky-100 shadow-sm flex flex-col md:flex-row gap-3 items-stretch md:items-center">
            <?php if(request('sort')): ?>
                <input type="hidden" name="sort" value="<?php echo e(request('sort')); ?>">
            <?php endif; ?>
            <?php if(request('direction')): ?>
                <input type="hidden" name="direction" value="<?php echo e(request('direction')); ?>">
            <?php endif; ?>

            
            <div class="soul-search-wrap relative flex-1">
                <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                </span>
                <input type="search" name="q" data-soul-search value="<?php echo e(request('q')); ?>" placeholder="Cari nama kelas (mis. 10 PPLG 1, DKV, dll)..."
                       class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
            </div>

            
            <div class="relative flex items-center gap-2">
                <button type="button" @click="openFilter = !openFilter"
                        class="px-4 py-2.5 rounded-2xl text-xs font-bold transition flex items-center gap-2 border <?php echo e($activeFilterCount > 0 ? 'bg-sky-50 border-sky-300 text-sky-700 shadow-sm shadow-sky-100' : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'); ?>">
                    <svg class="w-4 h-4 <?php echo e($activeFilterCount > 0 ? 'text-sky-600' : 'text-slate-500'); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/>
                    </svg>
                    <span>Filter Data</span>
                    <?php if($activeFilterCount > 0): ?>
                        <span class="w-5 h-5 rounded-full bg-sky-500 text-white text-[10px] font-black flex items-center justify-center">
                            <?php echo e($activeFilterCount); ?>

                        </span>
                    <?php endif; ?>
                </button>

                <button type="submit" class="px-5 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs rounded-2xl shadow-sm transition">
                    Cari
                </button>

                <?php if($hasActiveFilter): ?>
                    <a href="<?php echo e(route('kesiswaan.kelas.index')); ?>"
                       class="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-2xl transition"
                       title="Reset filter">
                        Reset
                    </a>
                <?php endif; ?>

                
                <div x-show="openFilter"
                     @click.away="openFilter = false"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 translate-y-2 scale-95"
                     x-transition:enter-end="opacity-100 translate-y-0 scale-100"
                     x-transition:leave="transition ease-in duration-150"
                     x-transition:leave-start="opacity-100 translate-y-0 scale-100"
                     x-transition:leave-end="opacity-0 translate-y-2 scale-95"
                     class="absolute right-0 top-full mt-2 w-80 md:w-96 bg-white rounded-3xl p-5 border border-sky-100 shadow-xl shadow-sky-900/10 z-50 space-y-4"
                     style="display: none;">
                    
                    <div class="flex items-center justify-between pb-3 border-b border-slate-100">
                        <div class="flex items-center gap-2">
                            <span class="p-1.5 rounded-lg bg-sky-50 text-sky-600">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/>
                                </svg>
                            </span>
                            <h4 class="text-xs font-bold text-slate-800">Opsi Filter Kelas</h4>
                        </div>
                        <button type="button" @click="openFilter = false" class="text-slate-400 hover:text-slate-600 text-sm font-bold">
                            &times;
                        </button>
                    </div>

                    <div class="space-y-3">
                        <div>
                            <label class="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">Tingkatan Kelas</label>
                            <select name="tingkat" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                                <option value="">Semua Tingkat</option>
                                <option value="x" <?php echo e(request('tingkat') === 'x' ? 'selected' : ''); ?>>Kelas 10 (X)</option>
                                <option value="xi" <?php echo e(request('tingkat') === 'xi' ? 'selected' : ''); ?>>Kelas 11 (XI)</option>
                                <option value="xii" <?php echo e(request('tingkat') === 'xii' ? 'selected' : ''); ?>>Kelas 12 (XII)</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">Tahun Ajaran</label>
                            <select name="tahun_ajaran_id" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                                <option value="">Semua Tahun Ajaran</option>
                                <?php $__currentLoopData = $tahunAjarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ta->id); ?>" <?php echo e(request('tahun_ajaran_id') == $ta->id ? 'selected' : ''); ?>>
                                        <?php echo e($ta->nama); ?> <?php echo e($ta->is_active ? '(Aktif)' : ''); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                        <a href="<?php echo e(route('kesiswaan.kelas.index', array_filter(['q' => request('q')]))); ?>"
                           class="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-700 transition">
                            Reset Opsi
                        </a>
                        <button type="submit" @click="openFilter = false"
                                class="px-5 py-2 bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs rounded-2xl shadow-sm transition">
                            Terapkan Filter
                        </button>
                    </div>
                </div>
            </div>
        </form>

        
        <?php if($hasActiveFilter): ?>
            <div class="flex flex-wrap items-center gap-2 pt-1 px-1">
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Filter Aktif:</span>

                <?php if(request()->filled('q')): ?>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 bg-sky-50 border border-sky-200 text-sky-700 rounded-xl text-xs font-semibold">
                        <span>Pencarian: "<strong><?php echo e(request('q')); ?></strong>"</span>
                        <a href="<?php echo e(route('kesiswaan.kelas.index', request()->except('q', 'page'))); ?>" class="hover:text-rose-500 transition">&times;</a>
                    </span>
                <?php endif; ?>

                <?php if(request()->filled('tingkat')): ?>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 bg-sky-50 border border-sky-200 text-sky-700 rounded-xl text-xs font-semibold">
                        <span>Tingkat: <strong>Kelas <?php echo e(strtoupper(request('tingkat'))); ?></strong></span>
                        <a href="<?php echo e(route('kesiswaan.kelas.index', request()->except('tingkat', 'page'))); ?>" class="hover:text-rose-500 transition">&times;</a>
                    </span>
                <?php endif; ?>

                <?php if(request()->filled('tahun_ajaran_id') && $selectedTa): ?>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 bg-sky-50 border border-sky-200 text-sky-700 rounded-xl text-xs font-semibold">
                        <span>Tahun Ajaran: <strong><?php echo e($selectedTa->nama); ?></strong></span>
                        <a href="<?php echo e(route('kesiswaan.kelas.index', request()->except('tahun_ajaran_id', 'page'))); ?>" class="hover:text-rose-500 transition">&times;</a>
                    </span>
                <?php endif; ?>

                <a href="<?php echo e(route('kesiswaan.kelas.index')); ?>" class="text-xs font-bold text-rose-500 hover:text-rose-600 hover:underline transition ml-1">
                    Hapus Semua Filter
                </a>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="bg-white rounded-3xl border border-sky-100 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-slate-50/70 border-b border-slate-100 text-[11px] font-bold text-slate-400 tracking-wider uppercase">
                        <th class="py-3.5 px-5">
                            <a href="<?php echo e($sortLink('nama')); ?>" class="inline-flex items-center gap-1.5 hover:text-sky-600 transition">
                                Kelas
                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="<?php echo e($sortIcon('nama')); ?>"/>
                                </svg>
                            </a>
                        </th>
                        <th class="py-3.5 px-5">Tahun Ajaran</th>
                        <th class="py-3.5 px-5">
                            <a href="<?php echo e($sortLink('siswas_count')); ?>" class="inline-flex items-center gap-1.5 hover:text-sky-600 transition">
                                Jumlah Siswa
                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="<?php echo e($sortIcon('siswas_count')); ?>"/>
                                </svg>
                            </a>
                        </th>
                        <th class="py-3.5 px-5 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-xs">
                    <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-sky-50/30 transition">
                            <td class="py-3.5 px-5">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-xl bg-sky-100 text-sky-700 font-black flex items-center justify-center text-xs shrink-0">
                                        <?php echo e(config("kelas.tingkat.{$k->tingkat}", $k->tingkat)); ?>

                                    </div>
                                    <div class="min-w-0">
                                        <a href="<?php echo e(route('kesiswaan.kelas.show', $k)); ?>" class="font-extrabold text-slate-900 hover:text-sky-600 transition block text-sm">
                                            <?php echo e($k->nama); ?>

                                        </a>
                                        <div class="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                                            <span><?php echo e($k->jurusan_label ?? strtoupper($k->jurusan)); ?></span>
                                            <span>&bull;</span>
                                            <span>Rombel <?php echo e($k->rombel); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <td class="py-3.5 px-5 whitespace-nowrap">
                                <div class="font-semibold text-slate-700"><?php echo e($k->tahunAjaran?->nama ?? '-'); ?></div>
                                <?php if($k->tahunAjaran?->is_active): ?>
                                    <span class="inline-block mt-0.5 px-2 py-0.5 rounded-full font-bold text-[10px] bg-emerald-50 text-emerald-600 border border-emerald-100">
                                        Aktif
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td class="py-3.5 px-5 whitespace-nowrap">
                                <a href="<?php echo e(route('kesiswaan.kelas.show', $k)); ?>"
                                   class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 hover:bg-sky-100 text-slate-700 hover:text-sky-700 transition"
                                   title="Lihat siswa di kelas ini">
                                    <svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                                    <span><?php echo e($k->siswas->count()); ?> Siswa</span>
                                </a>
                            </td>

                            <td class="py-3.5 px-5 text-right whitespace-nowrap">
                                <div class="flex gap-2 justify-end items-center">
                                    
                                    <a href="<?php echo e(route('kesiswaan.kelas.show', $k)); ?>"
                                       class="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs rounded-xl shadow-sm shadow-sky-200 transition"
                                       title="Lihat Siswa Kelas <?php echo e($k->nama); ?>">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                        Lihat Siswa
                                    </a>

                                    
                                    <button type="button"
                                            onclick='openEdit(<?php echo e(json_encode([
                                                "id" => $k->id,
                                                "nama" => $k->nama,
                                                "tingkat" => $k->tingkat,
                                                "jurusan" => $k->jurusan,
                                                "rombel" => $k->rombel,
                                                "tahun_ajaran_id" => $k->tahun_ajaran_id,
                                            ])); ?>)'
                                            class="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition">
                                        <svg class="w-3 h-3 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                        Edit
                                    </button>

                                    
                                    <form action="<?php echo e(route('kesiswaan.kelas.destroy', $k)); ?>" method="POST"
                                          onsubmit="return confirm('Hapus kelas <?php echo e($k->nama); ?>?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="inline-flex items-center gap-1 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 font-semibold rounded-xl text-xs transition">
                                            <svg class="w-3 h-3 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="py-12 text-center">
                                <div class="flex flex-col items-center justify-center text-slate-400">
                                    <svg class="w-10 h-10 mb-2 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                                    </svg>
                                    <p class="text-xs font-semibold text-slate-600">Tidak ada kelas yang ditemukan.</p>
                                    <p class="text-[11px] text-slate-400 mt-0.5">Coba ubah filter tingkatan atau kata kunci pencarian.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="px-6 py-4 border-t border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row gap-2 justify-between items-center">
            <p class="text-[11px] text-slate-400 font-semibold">
                Menampilkan <?php echo e($kelas->firstItem() ?? 0); ?>-<?php echo e($kelas->lastItem() ?? 0); ?> dari <?php echo e($kelas->total()); ?> kelas
            </p>
            <?php echo e($kelas->links()); ?>

        </div>
    </div>

    
    <dialog id="modal-create" class="rounded-3xl backdrop:bg-slate-900/40 p-0 w-full max-w-md shadow-2xl border border-sky-100">
        <form method="POST" action="<?php echo e(route('kesiswaan.kelas.store')); ?>" class="p-6 md:p-8 space-y-4 bg-white">
            <?php echo csrf_field(); ?>
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                    <h2 class="text-base font-extrabold text-slate-900">Tambah Kelas Baru</h2>
                    <p class="text-xs text-slate-400 mt-0.5">Konfigurasi rombel kelas sekolah</p>
                </div>
                <button type="button" onclick="this.closest('dialog').close()" class="w-8 h-8 rounded-full bg-slate-100 text-slate-400 hover:text-slate-600 flex items-center justify-center transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wide">Tingkat <span class="text-rose-500">*</span></label>
                <select name="tingkat" required data-tingkat
                        class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                    <option value="" disabled selected>Pilih tingkat...</option>
                    <?php $__currentLoopData = config('kelas.tingkat'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wide">Jurusan <span class="text-rose-500">*</span></label>
                <select name="jurusan" required data-jurusan disabled
                        class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition disabled:opacity-60">
                </select>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wide">Nomor Rombel <span class="text-slate-300 font-semibold normal-case tracking-normal">(opsional)</span></label>
                <input type="number" name="rombel" min="1" data-rombel
                       placeholder="Contoh: 1, 2, 3... (boleh dikosongkan)"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wide">Tahun Ajaran <span class="text-rose-500">*</span></label>
                <select name="tahun_ajaran_id" required
                        class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                    <option value="" disabled selected>Pilih tahun ajaran...</option>
                    <?php $__currentLoopData = $tahunAjarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ta->id); ?>" <?php echo e($ta->is_active ? 'selected' : ''); ?>>
                            <?php echo e($ta->nama); ?> <?php echo e($ta->is_active ? '(Aktif)' : ''); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="px-4 py-3 bg-sky-50 border border-sky-100 rounded-2xl">
                <span class="block text-[10px] font-bold text-sky-600 uppercase tracking-wide mb-0.5">Nama Kelas Terbentuk</span>
                <p data-preview class="text-sm font-extrabold text-sky-900">Pilih tingkat, jurusan, dan rombel</p>
            </div>

            <div class="flex gap-2.5 pt-3 border-t border-slate-100">
                <button type="button" onclick="this.closest('dialog').close()"
                        class="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl transition">
                    Batal
                </button>
                <button type="submit"
                        class="flex-1 px-5 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs rounded-2xl shadow-sm shadow-sky-200 transition">
                    Simpan Kelas
                </button>
            </div>
        </form>
    </dialog>

    
    <dialog id="modal-edit" class="rounded-3xl backdrop:bg-slate-900/40 p-0 w-full max-w-md shadow-2xl border border-sky-100">
        <form id="form-edit" method="POST" class="p-6 md:p-8 space-y-4 bg-white">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                    <h2 class="text-base font-extrabold text-slate-900">Edit Kelas</h2>
                    <p class="text-xs text-slate-400 mt-0.5">Perbarui data rombel kelas</p>
                </div>
                <button type="button" onclick="this.closest('dialog').close()" class="w-8 h-8 rounded-full bg-slate-100 text-slate-400 hover:text-slate-600 flex items-center justify-center transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wide">Tingkat <span class="text-rose-500">*</span></label>
                <select name="tingkat" required data-tingkat
                        class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                    <?php $__currentLoopData = config('kelas.tingkat'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wide">Jurusan <span class="text-rose-500">*</span></label>
                <select name="jurusan" required data-jurusan
                        class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </select>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wide">Nomor Rombel <span class="text-slate-300 font-semibold normal-case tracking-normal">(opsional)</span></label>
                <input type="number" name="rombel" min="1" data-rombel
                       placeholder="misal: 1, 2, 3... (boleh dikosongkan)"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wide">Tahun Ajaran <span class="text-rose-500">*</span></label>
                <select name="tahun_ajaran_id" required
                        class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                    <?php $__currentLoopData = $tahunAjarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ta->id); ?>"><?php echo e($ta->nama); ?> <?php echo e($ta->is_active ? '(Aktif)' : ''); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="px-4 py-3 bg-sky-50 border border-sky-100 rounded-2xl">
                <span class="block text-[10px] font-bold text-sky-600 uppercase tracking-wide mb-0.5">Nama Kelas Terbentuk</span>
                <p data-preview class="text-sm font-extrabold text-sky-900">Pilih tingkat, jurusan, dan rombel</p>
            </div>

            <div class="flex gap-2.5 pt-3 border-t border-slate-100">
                <button type="button" onclick="this.closest('dialog').close()"
                        class="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl transition">
                    Batal
                </button>
                <button type="submit"
                        class="flex-1 px-5 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs rounded-2xl shadow-sm shadow-sky-200 transition">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </dialog>

</div>

<script>
    const tingkatLabels = <?php echo json_encode(config('kelas.tingkat'), 15, 512) ?>;

    const jurusanMap = (function () {
        const map = {};
        const jurusan = <?php echo json_encode(config('kelas.jurusan'), 15, 512) ?>;
        Object.entries(jurusan).forEach(([kode, labels]) => {
            Object.keys(tingkatLabels).forEach((tingkat) => {
                if (labels[tingkat]) {
                    map[tingkat] = map[tingkat] || [];
                    map[tingkat].push({ value: kode, label: labels[tingkat] });
                }
            });
        });
        return map;
    })();

    function fillJurusan(select, tingkat, selectedValue) {
        select.innerHTML = '';
        if (!tingkat) {
            select.appendChild(placeholderOption('Pilih tingkat dulu...'));
            select.disabled = true;
            return;
        }

        select.disabled = false;
        (jurusanMap[tingkat] || []).forEach((j) => {
            const opt = document.createElement('option');
            opt.value = j.value;
            opt.textContent = j.label;
            select.appendChild(opt);
        });

        if (selectedValue && [...select.options].some((o) => o.value === selectedValue)) {
            select.value = selectedValue;
        } else if (!selectedValue) {
            select.appendChild(placeholderOption('Pilih jurusan...', true));
            select.selectedIndex = 0;
        }

        if (select.value && select.selectedIndex === -1) {
            select.selectedIndex = 0;
        }
    }

    function placeholderOption(text, isPlaceholder) {
        const opt = document.createElement('option');
        opt.value = '';
        opt.textContent = text;
        if (isPlaceholder) {
            opt.disabled = true;
            opt.selected = true;
        }
        return opt;
    }

    function updatePreview(form) {
        const tingkat = form.querySelector('[name=tingkat]').value;
        const jurusan = form.querySelector('[name=jurusan]').value;
        const rombel = form.querySelector('[name=rombel]').value;
        const tLabel = tingkatLabels[tingkat] || '';
        const jLabel = (jurusanMap[tingkat] || []).find((j) => j.value === jurusan)?.label || '';
        const preview = form.querySelector('[data-preview]');
        preview.textContent = [tLabel, jLabel, rombel].filter(Boolean).join(' ') || 'Pilih tingkat, jurusan, dan rombel';
    }

    function bindFormEvents(form) {
        const tingkat = form.querySelector('[name=tingkat]');
        const jurusan = form.querySelector('[name=jurusan]');
        const rombel = form.querySelector('[name=rombel]');

        tingkat.addEventListener('change', () => {
            fillJurusan(jurusan, tingkat.value, '');
            updatePreview(form);
        });
        jurusan.addEventListener('change', () => updatePreview(form));
        rombel.addEventListener('input', () => updatePreview(form));

        updatePreview(form);
    }

    bindFormEvents(document.querySelector('#modal-create form'));
    bindFormEvents(document.querySelector('#modal-edit form'));

    function openEdit(data) {
        const form = document.getElementById('form-edit');
        form.action = '<?php echo e(url('kesiswaan/kelas')); ?>/' + data.id;
        form.querySelector('[name=tingkat]').value = data.tingkat || '';
        fillJurusan(form.querySelector('[name=jurusan]'), data.tingkat || '', data.jurusan || '');
        form.querySelector('[name=rombel]').value = data.rombel || '';
        form.querySelector('[name=tahun_ajaran_id]').value = data.tahun_ajaran_id || '';
        updatePreview(form);
        document.getElementById('modal-edit').showModal();
    }

    (function restoreCreateForm() {
        const form = document.querySelector('#modal-create form');
        const oldTingkat = <?php echo json_encode(old('tingkat'), 15, 512) ?>;
        if (!oldTingkat) return;
        form.querySelector('[name=tingkat]').value = oldTingkat;
        fillJurusan(form.querySelector('[name=jurusan]'), oldTingkat, <?php echo json_encode(old('jurusan'), 15, 512) ?>);
        if (<?php echo json_encode(old('rombel'), 15, 512) ?>) form.querySelector('[name=rombel]').value = <?php echo json_encode(old('rombel'), 15, 512) ?>;
        if (<?php echo json_encode(old('tahun_ajaran_id'), 15, 512) ?>) form.querySelector('[name=tahun_ajaran_id]').value = <?php echo json_encode(old('tahun_ajaran_id'), 15, 512) ?>;
        updatePreview(form);
        document.getElementById('modal-create').showModal();
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kesiswaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Soul\resources\views/kesiswaan/kelas/index.blade.php ENDPATH**/ ?>