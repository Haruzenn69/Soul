<?php $__env->startSection('title', 'Import Akun '.($jenis === 'siswa' ? 'Siswa' : 'Guru')); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $isSiswa = $jenis === 'siswa';
        $templateRoute = $isSiswa ? 'kesiswaan.users.template-siswa' : 'kesiswaan.users.template-pembina';
        $columns = $isSiswa ? [
            ['NIS', 'Wajib, tepat 10 angka.'],
            ['Nama', 'Wajib diisi; hanya huruf alfabet, spasi, dan tanda baca nama (tidak boleh angka).'],
            ['Email', 'Opsional; jika diisi harus berformat email dan unik.'],
            ['Jenis Kelamin', 'Wajib: Laki-laki atau Perempuan (tersedia dropdown pilihan di file Excel).'],
            ['Tempat Lahir', 'Wajib diisi; tulis nama Kota/Kabupaten (contoh: Kota Bandung, Kabupaten Bogor, atau Bandung). Sistem otomatis menstandarkannya sesuai wilayah resmi.'],
            ['Tanggal Lahir', 'Wajib diisi; contoh: 26-06-2008 atau 2008-06-26.'],
            ['Agama', 'Wajib; pilih dari dropdown template (Islam, Kristen, Katolik, Hindu, Buddha, Khonghucu).'],
            ['No. Telp', 'Opsional, boleh dikosongkan.'],
            ['Alamat', 'Opsional, boleh dikosongkan.'],
            ['Media Sosial', 'Opsional, boleh dikosongkan.'],
        ] : [
            ['NIP', 'Wajib, tepat 18 angka.'],
            ['Nama Lengkap', 'Wajib diisi beserta gelar; hanya huruf alfabet, spasi, dan tanda baca gelar (tidak boleh angka).'],
            ['Email', 'Opsional; jika diisi harus berformat email dan unik.'],
            ['Jenis Kelamin', 'Wajib: Laki-laki atau Perempuan (tersedia dropdown pilihan di file Excel).'],
            ['Tempat Lahir', 'Wajib diisi; tulis nama Kota/Kabupaten (contoh: Kota Bandung, Kabupaten Bogor, atau Bandung). Sistem otomatis menstandarkannya sesuai wilayah resmi.'],
            ['Tanggal Lahir', 'Wajib diisi; contoh: 26-06-2008 atau 2008-06-26.'],
            ['Agama', 'Wajib; pilih dari dropdown template (Islam, Kristen, Katolik, Hindu, Buddha, Khonghucu).'],
            ['No. Telp', 'Opsional, boleh dikosongkan.'],
            ['Alamat', 'Opsional, boleh dikosongkan.'],
            ['Media Sosial', 'Opsional, boleh dikosongkan.'],
        ];
    ?>

    <div class="mx-auto max-w-5xl space-y-5">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h1 class="text-xl font-extrabold text-theme-dark">Import Akun <?php echo e($isSiswa ? 'Siswa' : 'Guru / Pembina'); ?></h1>
                <p class="mt-1 text-xs text-gray-500">Unduh template, lengkapi kolom sesuai keterangannya, lalu unggah file Excel atau CSV.</p>
            </div>
            <a href="<?php echo e(route('kesiswaan.users.create')); ?>" class="rounded-full bg-gray-100 px-5 py-2.5 text-xs font-bold text-gray-600 hover:bg-gray-200">Kembali ke Form Pembuatan Akun</a>
        </div>

        <?php if(session('error')): ?>
            <div role="alert" class="rounded-2xl border p-4 text-xs font-semibold border-red-200 bg-red-50 text-red-700">
                <?php echo e(session('error')); ?>

                <?php $__currentLoopData = session('import_errors', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $importError): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><p class="mt-1"><?php echo e($importError); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div role="alert" class="rounded-2xl border border-red-200 bg-red-50 p-4 text-xs font-semibold text-red-700">
                <p>File belum dapat diproses:</p>
                <ul class="mt-1 list-inside list-disc"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </div>
        <?php endif; ?>

        <section class="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm">
            <div class="flex flex-wrap items-center justify-between gap-4">
                <div>
                    <h2 class="text-sm font-extrabold text-theme-dark">1. Unduh template <?php echo e($isSiswa ? 'siswa' : 'guru'); ?></h2>
                    <p class="mt-1 text-xs text-gray-500">Gunakan nama kolom pada template dan jangan mengubah baris judul.</p>
                </div>
                <a href="<?php echo e(route($templateRoute)); ?>" class="rounded-full <?php echo e($isSiswa ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700'); ?> px-5 py-3 text-xs font-bold text-white">Unduh Template Excel</a>
            </div>

            <h3 class="mt-6 text-xs font-extrabold text-gray-700">Keterangan kolom</h3>
            <div class="mt-2 overflow-x-auto rounded-2xl border border-gray-100">
                <table class="w-full min-w-[520px] text-left text-xs">
                    <thead class="bg-gray-50 text-gray-500"><tr><th class="px-4 py-3 font-bold">Kolom</th><th class="px-4 py-3 font-bold">Aturan pengisian</th></tr></thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$column, $description]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td class="px-4 py-3 font-semibold text-gray-700"><?php echo e($column); ?></td><td class="px-4 py-3 text-gray-600"><?php echo e($description); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4 rounded-2xl bg-amber-50 p-4 text-xs leading-relaxed text-amber-800">
                <strong>Catatan Penting:</strong> Kolom <code>Username</code> tidak ada di Excel karena username dibuat mandiri oleh siswa atau pembina saat pertama kali login. Kolom <strong>Agama</strong> dan <strong>Jenis Kelamin</strong> telah dilengkapi dropdown pilihan di Excel. Email, No. Telp, dan Media Sosial boleh dikosongkan. Foto profil tidak ada di kolom Excel dan dapat ditambahkan setelah login. Tanggal dapat berupa sel tanggal Excel atau teks dengan format <strong>26-06-2008</strong> atau <strong>2008-06-26</strong>.
            </div>
        </section>

        <section class="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm">
            <h2 class="text-sm font-extrabold text-theme-dark">2. Unggah file</h2>
            <p class="mt-1 text-xs text-gray-500">Password akun hasil import adalah <code class="rounded bg-gray-100 px-1.5 py-0.5">password</code>.</p>
            <form method="POST" action="<?php echo e(route('kesiswaan.users.import')); ?>" enctype="multipart/form-data" class="mt-5 space-y-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="jenis" value="<?php echo e($jenis); ?>">
                <?php if($isSiswa): ?>
                    <div>
                        <label for="kelas-id" class="mb-1.5 block text-xs font-bold text-gray-500">Kelas tujuan siswa <span class="text-red-500">*</span></label>
                        <select id="kelas-id" name="kelas_id" required class="w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-xs text-gray-700">
                            <option value="">Pilih kelas</option>
                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>" <?php echo e(old('kelas_id') == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama); ?> (<?php echo e(config("kelas.tingkat.{$k->tingkat}")); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="mt-1 text-[11px] text-gray-400">Semua akun siswa dalam file akan dimasukkan ke kelas yang dipilih.</p>
                    </div>
                <?php endif; ?>
                <div>
                    <label for="file-import" class="mb-1.5 block text-xs font-bold text-gray-500">File Excel atau CSV <span class="text-red-500">*</span></label>
                    <input id="file-import" type="file" name="file" accept=".xlsx,.xls,.csv" required class="block w-full rounded-2xl border border-gray-200 bg-gray-50 p-3 text-xs text-gray-600">
                </div>
                <button type="submit" class="rounded-full <?php echo e($isSiswa ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700'); ?> px-6 py-3 text-xs font-bold text-white">Import Akun <?php echo e($isSiswa ? 'Siswa' : 'Guru'); ?></button>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kesiswaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Soul\resources\views/kesiswaan/users/import.blade.php ENDPATH**/ ?>