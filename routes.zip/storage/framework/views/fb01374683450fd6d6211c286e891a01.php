<?php $__env->startSection('title', 'Edit Akun'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-5 animate-fade-up">

    
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sky-400 via-blue-400 to-blue-600 p-6 md:p-8 text-white shadow-xl shadow-sky-200">
        
        <div class="absolute inset-0 pointer-events-none">
            <div class="absolute -bottom-24 -left-10 w-72 h-72 rounded-full bg-white/10 blur-3xl"></div>
            <div class="absolute -top-24 -right-10 w-72 h-72 rounded-full bg-white/10 blur-3xl"></div>
        </div>

        <div class="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
                <h1 class="text-2xl md:text-3xl font-extrabold tracking-tight leading-tight text-white">
                    Edit Akun: <?php echo e($user->username ?: $user->email); ?>

                </h1>
                <p class="text-xs text-white/80 mt-1.5 max-w-xl leading-relaxed">
                    Ubah data login, ganti role, atau kelola status akun ini melalui panel kesiswaan.
                </p>
            </div>

            <div class="flex gap-2.5 shrink-0 items-center flex-wrap">
                <a href="<?php echo e(route('kesiswaan.users.index')); ?>"
                   class="inline-flex items-center justify-center gap-2 px-5 py-3 bg-white/10 backdrop-blur border border-white/20 text-white font-bold text-xs rounded-2xl hover:bg-white/20 transition-all">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Kembali ke Daftar Akun
                </a>
            </div>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl text-xs font-semibold">
            <ul class="list-disc list-inside space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('kesiswaan.users.update', $user)); ?>" method="POST" enctype="multipart/form-data" id="form-edit-user" novalidate
          class="bg-white p-6 rounded-3xl border border-sky-100 shadow-sm space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Data Login -->
        <div>
            <h2 class="text-sm font-extrabold text-slate-900 mb-4">Data Login</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                        Username
                        <?php if(!$user->username): ?>
                            <span class="text-amber-500 font-normal text-[10px] lowercase">(belum diset oleh user)</span>
                        <?php endif; ?>
                    </label>
                    <input type="text" name="username" value="<?php echo e(old('username', $user->username)); ?>" placeholder="Belum diatur (diisi saat login pertama)"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Email</label>
                    <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Role</label>
                    <select name="role" id="role" required onchange="toggleRoleFields()"
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <?php
                            $roles = ['siswa' => 'Siswa', 'pembina' => 'Guru / Pembina', 'kesiswaan' => 'Kesiswaan'];
                            if (auth()->user()->role === 'admin') {
                                $roles = ['admin' => 'Admin'] + $roles;
                            }
                        ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('role', $user->role) === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Status Akun</label>
                    <select name="is_active" required
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <option value="1" <?php if((string) old('is_active', (int) $user->is_active) === '1'): echo 'selected'; endif; ?>>Aktif</option>
                        <option value="0" <?php if((string) old('is_active', (int) $user->is_active) === '0'): echo 'selected'; endif; ?>>Nonaktif</option>
                    </select>
                    <p class="mt-1 text-[10px] text-slate-400">Akun nonaktif tidak dapat digunakan untuk login.</p>
                </div>
            </div>
        </div>

        <!-- Data Siswa -->
        <div id="fields-siswa" class="hidden space-y-4">
            <h2 class="text-sm font-extrabold text-slate-900">Data Siswa</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1.5">NIS</label>
                    <input type="text" inputmode="numeric" maxlength="10" name="nis" value="<?php echo e(old('nis', $user->siswa?->nis)); ?>"
                           oninput="this.value = this.value.replace(/\D/g, '').slice(0, 10)"
                           class="w-full px-4 py-2.5 bg-gray-50 border border-gray-100 rounded-2xl text-xs focus:outline-none focus:bg-white focus:border-theme-blue transition">
                    <p class="text-[10px] text-gray-400 mt-1">Harus tepat 10 angka.</p>
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Nama Lengkap</label>
                    <input type="text" name="nama" value="<?php echo e(old('nama', $user->siswa?->nama)); ?>"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Kelas</label>
                    <select name="kelas_id"
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <option value="">Pilih kelas...</option>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e(old('kelas_id', $user->siswa?->kelas_id) == $k->id ? 'selected' : ''); ?>>
                                <?php echo e($k->nama); ?> (<?php echo e(config("kelas.tingkat.{$k->tingkat}")); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Angkatan</label>
                    <input type="text" name="angkatan" value="<?php echo e(old('angkatan', $user->siswa?->angkatan)); ?>" placeholder="Contoh: 2024 atau 2024/2025"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Jenis Kelamin</label>
                    <select name="jenis_kelamin"
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <option value="" <?php echo e(!old('jenis_kelamin', $user->siswa?->jenis_kelamin) ? 'selected' : ''); ?> disabled>Pilih...</option>
                        <option value="laki-laki" <?php echo e(old('jenis_kelamin', $user->siswa?->jenis_kelamin) === 'laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="perempuan" <?php echo e(old('jenis_kelamin', $user->siswa?->jenis_kelamin) === 'perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Agama</label>
                    <select name="agama"
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <option value="">Pilih Agama...</option>
                        <?php $__currentLoopData = ['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Khonghucu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($agm); ?>" <?php echo e(old('agama', $user->siswa?->agama) === $agm ? 'selected' : ''); ?>><?php echo e($agm); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" value="<?php echo e(old('tempat_lahir', $user->siswa?->tempat_lahir)); ?>" placeholder="Kota kelahiran"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir', $user->siswa?->tanggal_lahir?->format('Y-m-d'))); ?>"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">No. Telp / WA</label>
                    <input type="text" name="no_telp" value="<?php echo e(old('no_telp', $user->siswa?->no_telp)); ?>" placeholder="08xxxxxxxxxx"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Media Sosial</label>
                    <input type="text" name="medsos" value="<?php echo e(old('medsos', $user->siswa?->medsos)); ?>" placeholder="@username / link medsos"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Jabatan</label>
                    <select name="jabatan" id="jabatan"
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <?php $__currentLoopData = ['siswa' => 'Siswa', 'ketua' => 'Ketua Ekskul']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('jabatan', $user->siswa?->jabatan ?? 'siswa') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php
                    $currentEkskulId = $user->siswa?->pendaftarans->first()?->ekskul_id;
                ?>
                <div id="field-ekskul" class="hidden">
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Ekskul</label>
                    <select name="ekskul_id"
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <option value="">Pilih ekskul...</option>
                        <?php $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ek['id']); ?>" <?php echo e(old('ekskul_id', $currentEkskulId) == $ek['id'] ? 'selected' : ''); ?>

                                <?php echo e($ek['has_ketua'] ? 'disabled' : ''); ?>>
                                <?php echo e($ek['label']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p class="text-xs text-slate-400 mt-1 flex items-center gap-1">
                        <svg class="w-3.5 h-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                        </svg>
                        Ekskul yang sudah ada ketua tidak bisa dipilih.
                    </p>
                </div>
                <div class="md:col-span-3 flex items-center gap-4 p-3 bg-slate-50/80 rounded-2xl border border-slate-200/80">
                    <img src="<?php echo e($user->siswa?->foto_url ?? 'https://ui-avatars.com/api/?name='.urlencode($user->siswa?->nama ?? 'Siswa').'&background=0284c7&color=fff'); ?>"
                         alt="Foto Profil Siswa"
                         class="w-14 h-14 rounded-2xl object-cover border-2 border-white shadow-sm flex-shrink-0">
                    <div class="flex-1">
                        <label class="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">Ganti Foto Profil Siswa</label>
                        <input type="file" name="foto" accept="image/*"
                               class="w-full px-3 py-1.5 bg-white border border-slate-200/80 rounded-xl text-xs file:mr-3 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[11px] file:font-bold file:bg-sky-500 file:text-white hover:file:bg-sky-600 transition">
                        <p class="text-[10px] text-slate-400 mt-1">Format: JPG, PNG, WEBP. Maks 2MB.</p>
                    </div>
                </div>
                <div class="md:col-span-3">
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Alamat</label>
                    <textarea name="alamat" rows="2" placeholder="Alamat domisili lengkap"
                              class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition"><?php echo e(old('alamat', $user->siswa?->alamat)); ?></textarea>
                </div>
            </div>
        </div>

        <!-- Data Pembina -->
        <div id="fields-pembina" class="hidden space-y-4">
            <h2 class="text-sm font-extrabold text-slate-900">Data Pembina</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1.5">NIP *</label>
                    <input required type="text" inputmode="numeric" maxlength="18" name="nip" value="<?php echo e(old('nip', $user->pembina?->nip)); ?>"
                           oninput="this.value = this.value.replace(/\D/g, '').slice(0, 18)"
                           class="w-full px-4 py-2.5 bg-gray-50 border border-gray-100 rounded-2xl text-xs focus:outline-none focus:bg-white focus:border-theme-blue transition">
                    <p class="text-[10px] text-gray-400 mt-1">Harus tepat 18 angka.</p>
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Nama Lengkap *</label>
                    <input required type="text" name="pembina_nama" value="<?php echo e(old('pembina_nama', $user->pembina?->nama)); ?>"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Jenis Kelamin *</label>
                    <select required name="pembina_jenis_kelamin"
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <option value="" <?php echo e(!old('pembina_jenis_kelamin', $user->pembina?->jenis_kelamin) ? 'selected' : ''); ?> disabled>Pilih...</option>
                        <option value="laki-laki" <?php echo e(old('pembina_jenis_kelamin', $user->pembina?->jenis_kelamin) === 'laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="perempuan" <?php echo e(old('pembina_jenis_kelamin', $user->pembina?->jenis_kelamin) === 'perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Agama *</label>
                    <select required name="pembina_agama"
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                        <option value="">Pilih Agama...</option>
                        <?php $__currentLoopData = ['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Khonghucu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($agm); ?>" <?php echo e(old('pembina_agama', $user->pembina?->agama) === $agm ? 'selected' : ''); ?>><?php echo e($agm); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Tempat Lahir *</label>
                    <input required type="text" name="pembina_tempat_lahir" value="<?php echo e(old('pembina_tempat_lahir', $user->pembina?->tempat_lahir)); ?>" placeholder="Kota kelahiran"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Tanggal Lahir *</label>
                    <input required type="date" name="pembina_tanggal_lahir" value="<?php echo e(old('pembina_tanggal_lahir', $user->pembina?->tanggal_lahir?->format('Y-m-d'))); ?>"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">No. Telp / WA *</label>
                    <input required type="text" name="pembina_no_telp" value="<?php echo e(old('pembina_no_telp', $user->pembina?->no_telp)); ?>" placeholder="08xxxxxxxxxx"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div>
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Media Sosial (opsional)</label>
                    <input type="text" name="pembina_medsos" value="<?php echo e(old('pembina_medsos', $user->pembina?->medsos)); ?>" placeholder="@username / link medsos"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition">
                </div>
                <div class="md:col-span-3 flex items-center gap-4 p-3 bg-slate-50/80 rounded-2xl border border-slate-200/80">
                    <img src="<?php echo e($user->pembina?->foto_url ?? 'https://ui-avatars.com/api/?name='.urlencode($user->pembina?->nama ?? 'Pembina').'&background=0284c7&color=fff'); ?>"
                         alt="Foto Profil Pembina"
                         class="w-14 h-14 rounded-2xl object-cover border-2 border-white shadow-sm flex-shrink-0">
                    <div class="flex-1">
                        <label class="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">Ganti Foto Profil Pembina (opsional)</label>
                        <input type="file" name="pembina_foto" accept="image/*"
                               class="w-full px-3 py-1.5 bg-white border border-slate-200/80 rounded-xl text-xs file:mr-3 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[11px] file:font-bold file:bg-sky-500 file:text-white hover:file:bg-sky-600 transition">
                        <p class="text-[10px] text-slate-400 mt-1">Format: JPG, PNG, WEBP. Maks 2MB.</p>
                    </div>
                </div>
                <div class="md:col-span-3">
                    <label class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Alamat *</label>
                    <textarea required name="pembina_alamat" rows="2" placeholder="Alamat domisili lengkap"
                              class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition"><?php echo e(old('pembina_alamat', $user->pembina?->alamat)); ?></textarea>
                </div>
            </div>
        </div>

        
        <div class="flex items-center justify-between gap-3 pt-4 border-t border-slate-100 flex-wrap">
            <div class="flex items-center gap-2">
                <button type="submit" class="px-6 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs rounded-2xl shadow-sm shadow-sky-200 transition">
                    Simpan Perubahan
                </button>
                <a href="<?php echo e(route('kesiswaan.users.index')); ?>"
                   class="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl transition">Batal</a>
            </div>

            <?php if($user->id !== auth()->id()): ?>
                <button type="button" onclick="confirmDeleteUser()"
                        class="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 font-bold text-xs rounded-2xl transition flex items-center gap-1.5"
                        title="Hapus akun ini secara permanen">
                    <svg class="w-4 h-4 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                    </svg>
                    Hapus Akun
                </button>
            <?php endif; ?>
        </div>
    </form>

    <?php if($user->id !== auth()->id()): ?>
        <form id="delete-user-form" action="<?php echo e(route('kesiswaan.users.destroy', $user)); ?>" method="POST" class="hidden">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>
    <?php endif; ?>

    
    <dialog id="modalPeringatan"
            class="rounded-3xl backdrop:bg-slate-900/50 backdrop:backdrop-blur-sm p-0 w-full max-w-md shadow-2xl border border-amber-200/80 m-auto"
            onclick="if (event.target === this) closeEditWarning()">
        <div class="bg-white rounded-3xl p-6 overflow-hidden">
            
            <div class="flex items-start justify-between pb-3.5 border-b border-slate-100 gap-3">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-2xl bg-amber-100/90 text-amber-600 flex items-center justify-center shrink-0 border border-amber-200/80 shadow-sm shadow-amber-100">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-sm font-extrabold text-slate-900 leading-snug" id="modalPeringatanTitle">Peringatan Validasi</h3>
                        <p class="text-[11px] text-slate-400 font-medium">Periksa kembali data yang dimasukkan</p>
                    </div>
                </div>
                <button type="button" onclick="closeEditWarning()" class="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 flex items-center justify-center transition text-xs font-bold shrink-0">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>

            
            <div class="mt-4 space-y-3">
                <p class="text-xs text-slate-600 leading-relaxed font-medium" id="modalPeringatanMessage"></p>
                <div id="modalPeringatanList" class="space-y-1.5 max-h-56 overflow-y-auto pr-1 hidden"></div>
            </div>

            
            <div class="flex items-center justify-end gap-2.5 pt-4 mt-4 border-t border-slate-100">
                <button type="button" onclick="closeEditWarning()"
                        class="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition">
                    Tutup
                </button>
                <button type="button" onclick="confirmEditWarningAction()"
                        class="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold text-xs transition shadow-md shadow-amber-500/20 flex items-center gap-1.5">
                    <span id="modalPeringatanActionLabel">Periksa Sekarang</span>
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                </button>
            </div>
        </div>
    </dialog>
</div>

<script>
    let currentFocusTarget = null;
    function showEditWarning(title, message, items = [], focusTarget = null, actionLabel = 'Periksa Sekarang') {
        document.getElementById('modalPeringatanTitle').textContent = title || 'Peringatan Validasi';
        document.getElementById('modalPeringatanMessage').textContent = message || '';
        document.getElementById('modalPeringatanActionLabel').textContent = actionLabel;
        currentFocusTarget = focusTarget;

        const listEl = document.getElementById('modalPeringatanList');
        if (items && items.length > 0) {
            listEl.innerHTML = '';
            items.forEach((item, idx) => {
                const row = document.createElement('div');
                row.className = 'flex items-start gap-2.5 rounded-xl bg-amber-50/80 border border-amber-200/60 px-3 py-2 text-xs font-semibold text-amber-900';
                row.innerHTML = `<span class="w-4 h-4 rounded-full bg-amber-200/80 text-amber-800 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">${idx + 1}</span><span class="flex-1 leading-snug">${item}</span>`;
                listEl.appendChild(row);
            });
            listEl.classList.remove('hidden');
        } else {
            listEl.classList.add('hidden');
        }

        const dlg = document.getElementById('modalPeringatan');
        if (dlg) {
            if (typeof dlg.showModal === 'function') dlg.showModal();
            else dlg.setAttribute('open', '');
        }
    }

    function closeEditWarning() {
        const dlg = document.getElementById('modalPeringatan');
        if (dlg) {
            if (typeof dlg.close === 'function') dlg.close();
            else dlg.removeAttribute('open');
        }
    }

    function confirmEditWarningAction() {
        closeEditWarning();
        if (currentFocusTarget) {
            setTimeout(() => {
                const el = typeof currentFocusTarget === 'string' ? document.querySelector(currentFocusTarget) : currentFocusTarget;
                if (el) {
                    el.focus();
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }, 50);
        }
    }
    function toggleRoleFields() {
        const role = document.getElementById('role').value;
        const siswaFields = document.getElementById('fields-siswa');
        const pembinaFields = document.getElementById('fields-pembina');
        siswaFields.classList.toggle('hidden', role !== 'siswa');
        pembinaFields.classList.toggle('hidden', role !== 'pembina');
        siswaFields.querySelectorAll('input, select, textarea').forEach(field => field.disabled = role !== 'siswa');
        pembinaFields.querySelectorAll('input, select, textarea').forEach(field => field.disabled = role !== 'pembina');
        toggleEkskulField();
    }
    function toggleEkskulField() {
        const jabatan = document.getElementById('jabatan')?.value;
        document.getElementById('field-ekskul').classList.toggle('hidden', jabatan !== 'ketua');
    }
    function confirmDeleteUser() {
        if (confirm('Yakin ingin menghapus akun <?php echo e($user->username); ?>? Seluruh data yang terkait akan terhapus dan tindakan ini tidak dapat dibatalkan.')) {
            document.getElementById('delete-user-form').submit();
        }
    }
    document.addEventListener('DOMContentLoaded', () => {
        toggleRoleFields();
        document.getElementById('jabatan')?.addEventListener('change', toggleEkskulField);

        document.getElementById('form-edit-user')?.addEventListener('submit', function (e) {
            const emailEl = this.querySelector('input[name="email"]');
            if (emailEl) {
                const val = emailEl.value.trim();
                if (!val) {
                    e.preventDefault();
                    showEditWarning('Email Wajib Diisi', 'Alamat email wajib diisi untuk login akun.', [], emailEl, 'Isi Email');
                    return false;
                }
                if (!val.includes('@')) {
                    e.preventDefault();
                    showEditWarning('Format Email Tidak Valid', 'Alamat email harus menggunakan tanda "@" (contoh: user@sekolah.sch.id atau user@gmail.com).', [], emailEl, 'Perbaiki Email');
                    return false;
                }
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
                    e.preventDefault();
                    showEditWarning('Format Email Tidak Lengkap', 'Pastikan alamat email memiliki domain yang valid (contoh: user@gmail.com).', [], emailEl, 'Perbaiki Email');
                    return false;
                }
            }

            const role = document.getElementById('role')?.value;
            if (role === 'siswa') {
                const nisEl = this.querySelector('input[name="nis"]');
                if (nisEl) {
                    const nisVal = nisEl.value.trim();
                    if (!nisVal) {
                        e.preventDefault();
                        showEditWarning('NIS Wajib Diisi', 'NIS siswa wajib diisi tepat 10 angka.', [], nisEl, 'Isi NIS');
                        return false;
                    }
                    if (nisVal.length !== 10) {
                        e.preventDefault();
                        showEditWarning('Format NIS Tidak Sesuai', 'NIS harus terdiri dari tepat 10 digit angka (saat ini terisi ' + nisVal.length + ' angka).', [], nisEl, 'Perbaiki NIS');
                        return false;
                    }
                }
            } else if (role === 'pembina') {
                const nipEl = this.querySelector('input[name="nip"]');
                if (nipEl) {
                    const nipVal = nipEl.value.trim();
                    if (!nipVal) {
                        e.preventDefault();
                        showEditWarning('NIP Wajib Diisi', 'NIP pembina wajib diisi tepat 18 angka.', [], nipEl, 'Isi NIP');
                        return false;
                    }
                    if (nipVal.length !== 18 || !/^\d{18}$/.test(nipVal)) {
                        e.preventDefault();
                        showEditWarning('Format NIP Tidak Sesuai', 'NIP pembina harus terdiri dari tepat 18 digit angka (saat ini terisi ' + nipVal.length + ' angka).', [], nipEl, 'Perbaiki NIP');
                        return false;
                    }
                }
            }
        });

        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', function () {
                const file = this.files[0];
                if (file && file.size > 2 * 1024 * 1024) {
                    showEditWarning('Ukuran File Terlalu Besar', 'Ukuran file foto maksimal adalah 2MB. Silakan gunakan file gambar dengan ukuran lebih kecil.', [], this, 'Pilih File Lain');
                    this.value = '';
                }
            });
        });

        <?php if($errors->any()): ?>
            showEditWarning('Terjadi Kesalahan Validasi', 'Terdapat data yang belum sesuai dengan ketentuan sistem:', [
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    '<?php echo e(addslashes($err)); ?>',
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ], null, 'Periksa Sekarang');
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kesiswaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Soul\resources\views/kesiswaan/users/edit.blade.php ENDPATH**/ ?>