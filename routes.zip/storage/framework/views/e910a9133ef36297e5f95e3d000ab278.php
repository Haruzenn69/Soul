<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'as' => 'button',
    'href' => null,
    'type' => 'button',
    'depth' => 4,
    'tilt' => 7,
    'disabled' => false,
    'variant' => 'default',
    'size' => 'md',
    'active' => false,
    'align' => 'center',
    'block' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'as' => 'button',
    'href' => null,
    'type' => 'button',
    'depth' => 4,
    'tilt' => 7,
    'disabled' => false,
    'variant' => 'default',
    'size' => 'md',
    'active' => false,
    'align' => 'center',
    'block' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $faces = [
        'default' => 'border-stone-200 bg-white text-stone-700 dark:border-white/15 dark:bg-[#1D1D1A] dark:text-stone-200',
        'primary' => 'border-sky-600 bg-sky-600 text-white dark:border-sky-500 dark:bg-sky-500',
        'danger' => 'border-rose-600 bg-rose-600 text-white dark:border-rose-500 dark:bg-rose-500',
        'success' => 'border-emerald-600 bg-emerald-600 text-white dark:border-emerald-500 dark:bg-emerald-500',
    ];
    $face = $faces[$variant] ?? $faces['default'];
    $baseClass = 'bg-stone-300 dark:bg-white/20';
    if ($variant === 'primary') { $baseClass = 'bg-sky-800'; }
    if ($variant === 'danger') { $baseClass = 'bg-rose-800'; }
    if ($variant === 'success') { $baseClass = 'bg-emerald-800'; }
    if ($variant === 'filter') {
        $baseClass = $active ? 'bg-stone-300' : 'bg-sky-800';
        $face = $active
            ? 'border-white bg-white text-sky-700'
            : 'border-sky-500 bg-sky-600 text-white';
    }
    $sizes = [
        'sm' => 'h-8 px-3 text-xs',
        'md' => 'h-9 px-3.5 text-[13px]',
        'lg' => 'h-11 px-5 text-sm',
        'auto' => 'min-h-9 px-3.5 py-2 text-[13px]',
    ];
    $sizeClass = $sizes[$size] ?? $sizes['md'];
    $alignClass = $align === 'start' ? 'justify-start text-left' : 'justify-center';
    $blockClass = $block ? 'w-full' : '';
    $outerClass = 'group relative inline-flex select-none rounded-xl align-middle outline-none disabled:opacity-50';
    $disabledAttr = $disabled ? 'true' : 'false';
?>

<?php if($as === 'a'): ?>
    <a href="<?php echo e($href); ?>"
       x-data="{
            pressed: false,
            ox: 0,
            oy: 0,
            reduce: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
            start(e) {
                if (<?php echo e($disabledAttr); ?>) return;
                if (e.pointerType === 'mouse' && e.button !== 0) return;
                const r = e.currentTarget.getBoundingClientRect();
                this.ox = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width) * 2 - 1));
                this.oy = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height) * 2 - 1));
                this.pressed = true;
            },
            end() { this.pressed = false; },
            keyStart(e) {
                if (e.repeat) return;
                if (e.key === ' ' || e.key === 'Enter') this.pressed = true;
            },
            keyEnd(e) {
                if (e.key === ' ' || e.key === 'Enter' || e.key === 'Escape') this.pressed = false;
            }
       }"
       x-on:pointerdown="start($event)"
       x-on:pointerup="end()"
       x-on:pointercancel="end()"
       x-on:pointerleave="end()"
       x-on:keydown="keyStart($event)"
       x-on:keyup="keyEnd($event)"
       x-on:blur="end()"
       style="padding-bottom: <?php echo e($depth); ?>px; touch-action: manipulation; -webkit-tap-highlight-color: transparent;"
       <?php echo e($attributes->class([$outerClass])); ?>>
        <span aria-hidden="true" style="top: <?php echo e($depth); ?>px" class="absolute inset-x-0 bottom-0 rounded-xl <?php echo e($baseClass); ?>"></span>
        <span
            
            x-bind:style="`transition: transform 180ms cubic-bezier(.2,.9,.3,1.2); transform: perspective(340px) translateY(${pressed ? <?php echo e($depth); ?> : 0}px) rotateX(${pressed && !reduce ? -oy * <?php echo e($tilt); ?> : 0}deg) rotateY(${pressed && !reduce ? ox * <?php echo e($tilt); ?> : 0}deg)`"
            class="relative inline-flex items-center <?php echo e($alignClass); ?> <?php echo e($blockClass); ?> gap-2 rounded-xl border font-semibold <?php echo e($face); ?> <?php echo e($sizeClass); ?>">
            <span aria-hidden="true" class="pointer-events-none absolute inset-0 rounded-xl shadow-[inset_0_1.5px_0_rgba(255,255,255,0.55),inset_0_-1px_0_rgba(28,25,23,0.08)] transition-opacity" x-bind:class="pressed ? 'opacity-0' : 'opacity-100'"></span>
            <?php echo e($slot); ?>

        </span>
    </a>
<?php else: ?>
    <button type="<?php echo e($type); ?>"
            <?php if($disabled): ?> disabled <?php endif; ?>
            x-data="{
                pressed: false,
                ox: 0,
                oy: 0,
                reduce: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
                start(e) {
                    if (<?php echo e($disabledAttr); ?>) return;
                    if (e.pointerType === 'mouse' && e.button !== 0) return;
                    const r = e.currentTarget.getBoundingClientRect();
                    this.ox = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width) * 2 - 1));
                    this.oy = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height) * 2 - 1));
                    this.pressed = true;
                },
                end() { this.pressed = false; },
                keyStart(e) {
                    if (e.repeat) return;
                    if (e.key === ' ' || e.key === 'Enter') this.pressed = true;
                },
                keyEnd(e) {
                    if (e.key === ' ' || e.key === 'Enter' || e.key === 'Escape') this.pressed = false;
                }
            }"
            x-on:pointerdown="start($event)"
            x-on:pointerup="end()"
            x-on:pointercancel="end()"
            x-on:pointerleave="end()"
            x-on:keydown="keyStart($event)"
            x-on:keyup="keyEnd($event)"
            x-on:blur="end()"
            style="padding-bottom: <?php echo e($depth); ?>px; touch-action: manipulation; -webkit-tap-highlight-color: transparent;"
            <?php echo e($attributes->class([$outerClass])); ?>>
        <span aria-hidden="true" style="top: <?php echo e($depth); ?>px" class="absolute inset-x-0 bottom-0 rounded-xl <?php echo e($baseClass); ?>"></span>
        <span
            
            x-bind:style="`transition: transform 180ms cubic-bezier(.2,.9,.3,1.2); transform: perspective(340px) translateY(${pressed ? <?php echo e($depth); ?> : 0}px) rotateX(${pressed && !reduce ? -oy * <?php echo e($tilt); ?> : 0}deg) rotateY(${pressed && !reduce ? ox * <?php echo e($tilt); ?> : 0}deg)`"
            class="relative inline-flex items-center <?php echo e($alignClass); ?> <?php echo e($blockClass); ?> gap-2 rounded-xl border font-semibold <?php echo e($face); ?> <?php echo e($sizeClass); ?>">
            <span aria-hidden="true" class="pointer-events-none absolute inset-0 rounded-xl shadow-[inset_0_1.5px_0_rgba(255,255,255,0.55),inset_0_-1px_0_rgba(28,25,23,0.08)] transition-opacity" x-bind:class="pressed ? 'opacity-0' : 'opacity-100'"></span>
            <?php echo e($slot); ?>

        </span>
    </button>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Soul\resources\views/components/press-depth.blade.php ENDPATH**/ ?>