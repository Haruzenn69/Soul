@extends('pembina.layout')
@section('title', 'Profile Pembina')

@section('content')
    <div class="animate-fade-up">
        <h1 class="text-xl font-extrabold text-slate-900">Profile Saya</h1>
        <p class="text-xs text-slate-400 mt-0.5">Informasi akun dan ekskul yang anda bina</p>
    </div>

    @php $profileComplete = $pembina && $pembina->isProfileComplete(); @endphp

    @if(!$profileComplete)
        <div class="p-5 rounded-2xl border-2 border-dashed border-amber-300 bg-gradient-to-r from-amber-50 to-yellow-50 flex items-start gap-4 animate-fade-up">
            <div class="w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 text-white flex items-center justify-center shadow-md shadow-amber-200">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
            </div>
            <div>
                <h2 class="text-sm font-extrabold text-amber-900">Lengkapi Data Diri</h2>
                <p class="text-xs text-amber-700 mt-1">Data biodata yang belum lengkap perlu diperbarui oleh kesiswaan. Anda tetap dapat mengganti foto profil, nomor telepon, dan email di bawah.</p>
            </div>
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- KOLOM KIRI: Foto & Info Singkat -->
        <div class="lg:col-span-1">
            <div class="h-full bg-white p-6 rounded-3xl border border-sky-100 shadow-lg shadow-sky-100/60 text-center animate-fade-up" style="animation-delay: .1s">
                <div class="relative w-28 h-28 mx-auto rounded-full bg-slate-100 border-4 border-sky-300 flex items-center justify-center shadow-lg shadow-sky-200 overflow-hidden group">
                    <img id="pembina-avatar-img" src="{{ $pembina->foto_url }}" alt="Foto Profile" class="w-full h-full object-cover">
                </div>
                <h3 class="text-sm font-extrabold text-slate-900 mt-4">{{ $pembina->nama ?? '-' }}</h3>
                <p class="text-xs text-sky-600 font-bold">@ {{ auth()->user()->username }}</p>
                <p class="text-xs text-slate-400 mt-0.5">Pembina Ekskul</p>

                <div class="mt-4 pt-4 border-t border-sky-50 text-left space-y-2 text-xs">
                    <div class="flex items-center justify-between text-slate-500">
                        <span class="text-[11px] text-slate-400">Media Sosial:</span>
                        <span class="font-bold text-sky-700">{{ $pembina->medsos ?? '-' }}</span>
                    </div>
                    <div class="flex items-center justify-between text-slate-500">
                        <span class="text-[11px] text-slate-400">No. Telp / WA:</span>
                        <span class="font-semibold text-slate-700">{{ $pembina->no_telp ?? '-' }}</span>
                    </div>
                    <div class="flex items-center justify-between text-slate-500">
                        <span class="text-[11px] text-slate-400">Bergabung:</span>
                        <span class="font-semibold text-slate-700">{{ $pembina->created_at ? \Carbon\Carbon::parse($pembina->created_at)->isoFormat('D MMMM Y') : '-' }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- KOLOM KANAN -->
        <div class="lg:col-span-2 space-y-6">
            <!-- UBAH / LENGKAPI DATA Diri -->
            <div class="bg-white p-6 rounded-2xl border border-sky-100 shadow-lg shadow-sky-100/60 animate-fade-up" style="animation-delay: .12s">
                <h2 class="text-sm font-extrabold text-slate-900 mb-1">Data yang Dapat Diubah</h2>
                <p class="text-[11px] text-slate-400 mb-4">Anda dapat mengubah foto profil, nomor telepon, dan email. Data biodata lainnya dikelola kesiswaan.</p>
                <form method="POST" action="{{ route('pembina.profile.update') }}" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    @csrf
                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Nama Lengkap</label>
                        <div class="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs text-slate-700 font-bold">
                            {{ $pembina->nama ?? '-' }}
                        </div>
                        <p class="text-[10px] text-slate-400 mt-1.5">Ditetapkan oleh kesiswaan.</p>
                    </div>

                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Username Login <span class="text-rose-500">*</span></label>
                        <div class="relative">
                            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">@</span>
                            <input type="text" name="username" value="{{ old('username', auth()->user()->username) }}" required
                                   class="w-full pl-8 pr-4 py-2.5 bg-sky-50/60 border @error('username') border-rose-300 @else border-sky-100 @enderror rounded-xl text-xs font-semibold focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                        </div>
                        <p class="text-[10px] text-slate-400 mt-1.5">Gunakan username yang mudah diingat untuk login.</p>
                    </div>

                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Foto Profil</label>
                        <input type="file" name="foto" accept="image/jpeg,image/png,image/jpg,image/webp"
                               onchange="if(this.files && this.files[0]){ const r = new FileReader(); r.onload = e => { const img = document.getElementById('pembina-avatar-img'); if(img){ img.src = e.target.result; } }; r.readAsDataURL(this.files[0]); }"
                               class="w-full px-3 py-2 bg-sky-50/60 border @error('foto') border-rose-300 @else border-sky-100 @enderror rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-sky-500 file:text-white hover:file:bg-sky-600">
                        <p class="text-[10px] text-slate-400 mt-1.5">Format JPG/PNG/WebP, maksimal 2MB.</p>
                    </div>

                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Jenis Kelamin (dikelola kesiswaan)</label>
                        <select disabled
                                class="w-full px-4 py-2.5 bg-sky-50/60 border @error('jenis_kelamin') border-red-300 @else border-sky-100 @enderror rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                            <option value="" {{ !$pembina?->jenis_kelamin ? 'selected' : '' }} disabled>Pilih...</option>
                            <option value="laki-laki" {{ old('jenis_kelamin', $pembina?->jenis_kelamin) === 'laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                            <option value="perempuan" {{ old('jenis_kelamin', $pembina?->jenis_kelamin) === 'perempuan' ? 'selected' : '' }}>Perempuan</option>
                        </select>
                    </div>

                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Agama (dikelola kesiswaan)</label>
                        <select disabled
                                class="w-full px-4 py-2.5 bg-sky-50/60 border border-sky-100 rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                            <option value="">Pilih Agama...</option>
                            @foreach (['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Khonghucu'] as $agm)
                                <option value="{{ $agm }}" {{ old('agama', $pembina->agama) === $agm ? 'selected' : '' }}>{{ $agm }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Tempat Lahir (dikelola kesiswaan)</label>
                        <input disabled type="text" value="{{ $pembina->tempat_lahir }}" placeholder="Kota kelahiran"
                               class="w-full px-4 py-2.5 bg-sky-50/60 border border-sky-100 rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                    </div>

                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Tanggal Lahir (dikelola kesiswaan)</label>
                        <input disabled type="date" value="{{ $pembina->tanggal_lahir?->format('Y-m-d') }}"
                               class="w-full px-4 py-2.5 bg-sky-50/60 border border-sky-100 rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                    </div>

                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">No. Telp / WhatsApp</label>
                        <input type="text" name="no_telp" value="{{ old('no_telp', $pembina->no_telp) }}" placeholder="08xxxxxxxxxx"
                               class="w-full px-4 py-2.5 bg-sky-50/60 border border-sky-100 rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                    </div>

                    <div>
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Email (opsional)</label>
                        <input type="email" name="email" value="{{ old('email', auth()->user()->email ?? '') }}" placeholder="contoh@email.com"
                               class="w-full px-4 py-2.5 bg-sky-50/60 border @error('email') border-red-300 @else border-sky-100 @enderror rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                    </div>

                    {{-- MEDIA SOSIAL DENGAN SISTEM ARAHAN --}}
                    <div class="md:col-span-2">
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Media Sosial (dikelola kesiswaan)</label>
                        <input disabled type="text" value="{{ $pembina->medsos }}" placeholder="misal: @nama_pembina (Instagram) / link profil medsos"
                               class="w-full px-4 py-2.5 bg-sky-50/60 border border-sky-100 rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                        <div class="mt-2 p-2.5 bg-sky-50 border border-sky-100 rounded-xl text-[11px] text-sky-800 flex items-start gap-2">
                            <span>💡</span>
                            <span><b>Arahan Sistem:</b> Cantumkan akun Instagram atau kontak publik Anda agar anggota dan kesiswaan dapat berkoordinasi secara cepat untuk kebutuhan ekskul.</span>
                        </div>
                    </div>

                    <div class="md:col-span-2">
                        <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Alamat Lengkap</label>
                        <textarea disabled rows="2" placeholder="Alamat domisili lengkap"
                                  class="w-full px-4 py-2.5 bg-sky-50/60 border border-sky-100 rounded-xl text-xs focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">{{ old('alamat', $pembina->alamat) }}</textarea>
                    </div>

                    <div class="md:col-span-2 pt-2">
                        <button type="submit" class="px-6 py-2.5 bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white text-xs font-bold rounded-xl shadow-md shadow-sky-200 transition hover:-translate-y-0.5">
                            Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>

            <!-- UBAH PASSWORD -->
            <div class="bg-white p-6 rounded-2xl border border-sky-100 shadow-lg shadow-sky-100/60 animate-fade-up" style="animation-delay: .14s">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h2 class="text-sm font-extrabold text-slate-900">Ubah Password</h2>
                        <p class="text-[11px] text-slate-400 mt-0.5">Pastikan akun Anda menggunakan password yang aman dan mudah diingat</p>
                    </div>
                    <div class="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-100">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                </div>

                <form method="POST" action="{{ route('password.update') }}" class="space-y-4">
                    @csrf
                    @method('PUT')

                    <div>
                        <label for="pembina_current_password" class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                            Password Saat Ini <span class="text-rose-500">*</span>
                        </label>
                        <input type="password" id="pembina_current_password" name="current_password" required autocomplete="current-password" placeholder="Masukkan password saat ini"
                               class="w-full px-4 py-2.5 bg-sky-50/60 border {{ $errors->updatePassword->has('current_password') ? 'border-rose-300' : 'border-sky-100' }} rounded-xl text-xs font-semibold focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                        @if($errors->updatePassword->has('current_password'))
                            <p class="text-rose-500 text-[10px] mt-1 font-bold">{{ $errors->updatePassword->first('current_password') }}</p>
                        @endif
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="pembina_password" class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                                Password Baru <span class="text-rose-500">*</span>
                            </label>
                            <input type="password" id="pembina_password" name="password" required autocomplete="new-password" placeholder="Minimal 8 karakter"
                                   class="w-full px-4 py-2.5 bg-sky-50/60 border {{ $errors->updatePassword->has('password') ? 'border-rose-300' : 'border-sky-100' }} rounded-xl text-xs font-semibold focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                            @if($errors->updatePassword->has('password'))
                                <p class="text-rose-500 text-[10px] mt-1 font-bold">{{ $errors->updatePassword->first('password') }}</p>
                            @else
                                <p class="text-[10px] text-slate-400 mt-1">Minimal 8 karakter.</p>
                            @endif
                        </div>

                        <div>
                            <label for="pembina_password_confirmation" class="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                                Konfirmasi Password Baru <span class="text-rose-500">*</span>
                            </label>
                            <input type="password" id="pembina_password_confirmation" name="password_confirmation" required autocomplete="new-password" placeholder="Ulangi password baru"
                                   class="w-full px-4 py-2.5 bg-sky-50/60 border {{ $errors->updatePassword->has('password_confirmation') ? 'border-rose-300' : 'border-sky-100' }} rounded-xl text-xs font-semibold focus:outline-none focus:bg-white focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition">
                            @if($errors->updatePassword->has('password_confirmation'))
                                <p class="text-rose-500 text-[10px] mt-1 font-bold">{{ $errors->updatePassword->first('password_confirmation') }}</p>
                            @endif
                        </div>
                    </div>

                    <div class="pt-2">
                        <button type="submit" class="px-6 py-2.5 bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white text-xs font-bold rounded-xl shadow-md shadow-sky-200 transition hover:-translate-y-0.5">
                            Perbarui Password
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 xl:grid-cols-2 gap-6 items-stretch">
            <!-- Data Diri Ringkas -->
            <div class="h-full bg-white p-6 rounded-3xl border border-sky-100 shadow-lg shadow-sky-100/60 animate-fade-up" style="animation-delay: .15s">
                <h2 class="text-sm font-extrabold text-slate-900 mb-4">Data Diri</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="p-3.5 bg-gradient-to-r from-sky-50 to-white rounded-xl border border-sky-100">
                        <p class="text-[10px] font-semibold text-slate-400 tracking-wider uppercase">Nama Lengkap</p>
                        <p class="text-sm font-bold text-slate-800 mt-1">{{ $pembina->nama ?? '-' }}</p>
                    </div>
                    <div class="p-3.5 bg-gradient-to-r from-amber-50 to-white rounded-xl border border-amber-100">
                        <p class="text-[10px] font-semibold text-slate-400 tracking-wider uppercase">NIP</p>
                        <p class="text-sm font-bold text-slate-800 mt-1">{{ $pembina->nip ?? '-' }}</p>
                    </div>
                    <div class="p-3.5 bg-gradient-to-r from-sky-50 to-white rounded-xl border border-sky-100">
                        <p class="text-[10px] font-semibold text-slate-400 tracking-wider uppercase">Jenis Kelamin</p>
                        <p class="text-sm font-bold text-slate-800 mt-1">{{ ucfirst($pembina->jenis_kelamin ?? '-') }}</p>
                    </div>
                    <div class="p-3.5 bg-gradient-to-r from-amber-50 to-white rounded-xl border border-amber-100">
                        <p class="text-[10px] font-semibold text-slate-400 tracking-wider uppercase">Username</p>
                        <p class="text-sm font-bold text-slate-800 mt-1">{{ auth()->user()->username ?? '-' }}</p>
                    </div>
                    <div class="p-3.5 bg-gradient-to-r from-sky-50 to-white rounded-xl border border-sky-100">
                        <p class="text-[10px] font-semibold text-slate-400 tracking-wider uppercase">Email</p>
                        <p class="text-sm font-bold text-slate-800 mt-1">{{ auth()->user()->email ?? '-' }}</p>
                    </div>
                    <div class="p-3.5 bg-gradient-to-r from-amber-50 to-white rounded-xl border border-amber-100">
                        <p class="text-[10px] font-semibold text-slate-400 tracking-wider uppercase">Media Sosial</p>
                        <p class="text-sm font-bold text-slate-800 mt-1">{{ $pembina->medsos ?? '-' }}</p>
                    </div>
                </div>
            </div>

            <!-- Ekskul yang Dibina -->
            <div class="h-full bg-white p-6 rounded-3xl border border-sky-100 shadow-lg shadow-sky-100/60 animate-fade-up" style="animation-delay: .2s">
                <h2 class="text-sm font-extrabold text-slate-900 mb-4">Ekskul yang Dibina</h2>
                @php
                    $ekskuls = $pembina ? $pembina->ekskuls()->get() : collect();
                @endphp
                @if($ekskuls->count() > 0)
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        @foreach($ekskuls as $ekskul)
                            <div class="p-4 bg-gradient-to-r from-sky-50 to-amber-50 rounded-xl border border-sky-100">
                                <div class="flex items-center justify-between gap-2">
                                    <h4 class="text-xs font-extrabold text-slate-900 truncate">{{ $ekskul->nama_ekskul }}</h4>
                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold border shrink-0 {{ $ekskul->is_open_recruitment ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-600 border-slate-200' }}">
                                        {{ $ekskul->is_open_recruitment ? 'Open' : 'Tutup' }}
                                    </span>
                                </div>
                                @if($ekskul->jadwal)
                                    <p class="text-[11px] text-slate-500 mt-2">Jadwal: {{ $ekskul->jadwal }}</p>
                                @endif
                                <p class="text-[10px] text-slate-400 mt-1">Anggota aktif: {{ $ekskul->pendaftarans()->where('status', 'diterima')->count() }}</p>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="text-center py-6 text-slate-400">
                        <p class="text-sm">Belum ada ekskul yang anda bina.</p>
                    </div>
                @endif
        </div>
    </div>
@endsection
