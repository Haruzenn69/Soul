@extends('ketua.layout')
@section('title', 'Daftar Laporan Bulanan')

@section('content')
<div class="space-y-6">
    <!-- Page Header -->
    <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
        <div>
            <h1 class="text-xl md:text-2xl font-extrabold text-slate-900">Daftar Laporan Bulanan</h1>
            <p class="text-xs text-slate-400 mt-1">Total: {{ $total }} laporan</p>
        </div>
        <a href="{{ route('ketua.laporan-bulanan.create') }}" class="px-5 py-2.5 bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white font-bold text-xs rounded-xl shadow-lg shadow-sky-200 transition inline-flex w-full sm:w-auto items-center justify-center gap-2 shrink-0">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Laporan Baru
        </a>
    </div>

    @include('partials.table-filters', [
        'action' => route('ketua.laporan-bulanan.index'),
        'placeholder' => 'Cari bulan / materi...',
        'filters' => [
            ['name' => 'status', 'allLabel' => 'Semua Status', 'options' => ['draft' => 'Draft', 'menunggu' => 'Menunggu Pembina', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak']],
        ],
    ])

    <!-- Table Card -->
    <div class="ketua-card-list bg-white rounded-2xl border border-sky-100 shadow-lg shadow-sky-100/60 overflow-hidden">
        <div class="overflow-x-auto">
        <table class="card-table ketua-card-laporan w-full text-left text-xs md:text-sm">
            <thead class="bg-gradient-to-r from-sky-50 to-blue-50">
                <tr>
                    <th class="px-4 md:px-6 py-3 font-semibold text-slate-500 whitespace-nowrap">No</th>
                    @include('partials.th-sort', ['label' => 'Bulan', 'key' => 'bulan', 'sort' => $sort, 'direction' => $direction, 'class' => 'px-4 md:px-6 py-3 font-semibold text-slate-500 whitespace-nowrap'])
                    <th class="px-4 md:px-6 py-3 font-semibold text-slate-500 whitespace-nowrap">Materi</th>
                    @include('partials.th-sort', ['label' => 'Status', 'key' => 'status', 'sort' => $sort, 'direction' => $direction, 'class' => 'px-4 md:px-6 py-3 font-semibold text-slate-500 whitespace-nowrap'])
                    <th class="px-4 md:px-6 py-3 font-semibold text-slate-500 whitespace-nowrap">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-sky-50">
                @forelse($laporans as $laporan)
                    <tr class="hover:bg-sky-50/50 transition" data-card-href="{{ route('ketua.laporan-bulanan.show', $laporan) }}">
                        <td class="px-4 md:px-6 py-3.5 whitespace-nowrap">{{ $loop->iteration }}</td>
                        <td class="px-4 md:px-6 py-3.5 whitespace-nowrap">{{ $laporan->bulan }}</td>
                        <td class="px-4 md:px-6 py-3.5 max-w-md">
                            <span title="{{ $laporan->materi_kegiatan ?? '-' }}">
                                {{ \Illuminate\Support\Str::limit($laporan->materi_kegiatan ?? '-', 90) }}
                            </span>
                        </td>
                        <td class="px-4 md:px-6 py-3.5 whitespace-nowrap">
                            @if($laporan->status === 'draft')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">Draft</span>
                            @elseif($laporan->status === 'menunggu')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-sky-100 text-sky-700 border border-sky-200">Menunggu Pembina</span>
                            @elseif($laporan->status === 'disetujui')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700 border border-emerald-200">Disetujui</span>
                            @else
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-700 border border-rose-200">Ditolak</span>
                            @endif
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-2">
                                <a href="{{ route('ketua.laporan-bulanan.show', $laporan) }}" class="card-detail-link px-3 py-1.5 bg-gradient-to-r from-sky-100 to-blue-100 text-sky-700 font-bold rounded-xl hover:from-sky-200 hover:to-blue-200 transition text-xs">Detail</a>
                                @if(in_array($laporan->status, ['draft', 'ditolak']))
                                    <a href="{{ route('ketua.laporan-bulanan.edit', $laporan) }}" class="px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-700 font-bold rounded-xl transition text-xs">Edit</a>
                                @endif
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-4 md:px-6 py-10 text-center text-slate-400">Belum ada laporan bulanan. Buat laporan untuk periode berjalan.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
        </div>
        @include('partials.table-pagination', ['rows' => $laporans, 'label' => 'laporan'])
    </div>
@endsection
